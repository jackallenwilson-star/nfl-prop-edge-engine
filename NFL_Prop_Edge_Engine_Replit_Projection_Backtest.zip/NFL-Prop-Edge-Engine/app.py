from __future__ import annotations
import json, traceback
from datetime import datetime, timezone
import pandas as pd
import streamlit as st
import plotly.express as px

from config import APP_NAME, MODEL_VERSION, LOCAL_TIMEZONE, BACKTEST_START_SEASON
from nfl_data import load_core_data, NFLVerseClient
from schedule import normalize_schedule, current_season_week
from kalshi_api import KalshiClient
from market_discovery import discover_current_week_markets
from market_parser import normalize_market
from player_matching import find_player_match, game_matches_market
from player_status import status_for_player
from features import prepare_player_games, prepare_historical_player_games, summarize_player
from predictions import predict_market
from diagnostics import quote_freshness
from database import init_db, save_run, load_latest_predictions, load_run_history
from backtesting import run_stat_backtest
from fantasy_model import fantasy_points, ppr_scoring

st.set_page_config(page_title=APP_NAME, page_icon="🏈", layout="wide", initial_sidebar_state="expanded")
st.markdown("""<style>
.stApp {background: #0b1020; color: #eef2ff;}
[data-testid="stSidebar"] {background: #111a2d;}
[data-testid="stMetric"] {background: #111a2d; border: 1px solid #27344d; padding: 12px; border-radius: 10px;}
div.stButton > button {border-radius: 9px; border: 1px solid #3a4a68; font-weight: 650;}
.block-container {padding-top: 1.5rem;}
.edge-positive {color:#35d39a;font-weight:700;} .edge-negative {color:#ff6b78;font-weight:700;}
.small-muted {color:#9caac4;font-size:0.85rem;}
</style>""", unsafe_allow_html=True)

init_db()

if "analysis" not in st.session_state:
    persisted = load_latest_predictions()
    st.session_state.analysis = {"predictions": persisted, "games": pd.DataFrame(), "markets": [],
                                 "diagnostics": {}, "data": {}, "season": None, "week": None,
                                 "player_games": pd.DataFrame(), "historical_games": pd.DataFrame(), "run_at": None}
if "selected_game" not in st.session_state: st.session_state.selected_game = None


def fmt_pct(v): return f"{v*100:.1f}%" if v is not None and pd.notna(v) else "—"
def fmt_num(v, n=1): return f"{v:.{n}f}" if v is not None and pd.notna(v) else "—"
def fmt_edge(v): return f"{v:+.1f} pp" if v is not None and pd.notna(v) else "UNAVAILABLE"


def player_frame_from_sources(data: dict, season: int, week: int, teams: set[str]) -> pd.DataFrame:
    stats = data.get("stats")
    directory = data.get("players")
    rosters = data.get("rosters")
    # Prefer the canonical identity directory, then attach current-week team from roster data.
    base = directory if directory is not None and not directory.empty else stats
    if base is None or base.empty: return pd.DataFrame()
    name = next((c for c in ("player_display_name", "player_name", "display_name", "full_name") if c in base.columns), None)
    pid = next((c for c in ("gsis_id", "player_id") if c in base.columns), None)
    if not name or not pid: return pd.DataFrame()
    team_source = next((c for c in ("recent_team", "team", "team_abbr") if c in base.columns), None)
    keep = [name, pid] + ([team_source] if team_source else []) + (["position"] if "position" in base.columns else [])
    base = base[keep].dropna(subset=[name, pid]).drop_duplicates(pid, keep="last").copy()
    base = base.rename(columns={name: "player_display_name", pid: "player_id"})
    base["player_id"] = base.player_id.astype(str)
    if "position" not in base: base["position"] = ""

    # If using the identity directory and no current-week roster is available, attach
    # the most recent current-season team observed in the stats release.
    if stats is not None and not stats.empty and "season" in stats.columns:
        stat_id = next((c for c in ("player_id", "gsis_id") if c in stats.columns), None)
        stat_team = next((c for c in ("recent_team", "team", "team_abbr") if c in stats.columns), None)
        if stat_id and stat_team:
            ss = stats[pd.to_numeric(stats.season, errors="coerce").eq(int(season))].copy()
            if "week" in ss: ss = ss.sort_values("week")
            team_map = ss[[stat_id, stat_team]].dropna().drop_duplicates(stat_id, keep="last")
            team_map = team_map.rename(columns={stat_id:"player_id", stat_team:"stats_team"})
            team_map.player_id = team_map.player_id.astype(str)
            base = base.merge(team_map, on="player_id", how="left")

    if rosters is not None and not rosters.empty:
        r = rosters.copy()
        rid = next((c for c in ("gsis_id", "player_id") if c in r.columns), None)
        teamcol = next((c for c in ("team", "recent_team", "team_abbr") if c in r.columns), None)
        if rid and teamcol:
            if "season" in r: r = r[pd.to_numeric(r.season, errors="coerce").eq(int(season))]
            if "week" in r: r = r[pd.to_numeric(r.week, errors="coerce").eq(int(week))]
            r = r[[rid, teamcol] + (["position"] if "position" in r.columns else [])].drop_duplicates(rid, keep="last")
            r = r.rename(columns={rid:"player_id", teamcol:"recent_team", "position":"roster_position"})
            r.player_id = r.player_id.astype(str)
            base = base.drop(columns=["recent_team"], errors="ignore")
            base = base.merge(r, on="player_id", how="inner")
            base = base[base.recent_team.astype(str).str.upper().isin(teams)]
            if "roster_position" in base:
                base["position"] = base["roster_position"].fillna(base["position"])
    else:
        fallback_team = "stats_team" if "stats_team" in base.columns else team_source
        if fallback_team and fallback_team in base.columns:
            base = base[base[fallback_team].astype(str).str.upper().isin(teams)].copy()
            base["recent_team"] = base[fallback_team]
        else:
            base = base.iloc[0:0].copy()  # No team verification means no player match.
    return base.drop_duplicates("player_id").reset_index(drop=True)


def market_is_fresh(market: dict) -> dict:
    f = quote_freshness(market)
    row = dict(market); row.update(f)
    if not f["quote_fresh"]:
        row["market_yes_probability_observed"] = row.get("market_yes_probability")
        row["market_no_probability_observed"] = row.get("market_no_probability")
        row["market_yes_probability"] = None; row["market_no_probability"] = None
    return row


def process_markets(markets, games, data, player_games):
    predictions, game_markets, unmatched = [], [], []
    stats = data.get("stats")
    rosters = data.get("rosters")
    injuries = data.get("injuries")
    current_season = int(games.iloc[0]["season"]) if not games.empty else None
    current_week = int(games.iloc[0]["week"]) if not games.empty else None
    if rosters is not None and not rosters.empty and current_season is not None:
        if "season" in rosters.columns:
            rosters = rosters[pd.to_numeric(rosters.season, errors="coerce").eq(current_season)]
        if "week" in rosters.columns:
            rosters = rosters[pd.to_numeric(rosters.week, errors="coerce").eq(current_week)]
    if injuries is not None and not injuries.empty and current_season is not None and "season" in injuries.columns:
        injuries = injuries[pd.to_numeric(injuries.season, errors="coerce").eq(current_season)]
        if "week" in injuries.columns:
            injuries = injuries[pd.to_numeric(injuries.week, errors="coerce").eq(current_week)]
        modified = next((c for c in ("date_modified", "updated_at", "report_date") if c in injuries.columns), None)
        if modified: injuries = injuries.sort_values(modified)
    for market0 in markets:
        market = market_is_fresh(normalize_market(market0))
        if market.get("category") == "FUTURE":
            continue
        candidates = []
        for _, g in games.iterrows():
            gd = g.to_dict()
            if game_matches_market(gd, market): candidates.append(gd)
        if len(candidates) != 1:
            unmatched.append({"ticker": market.get("ticker"), "title": market.get("title"),
                              "reason": "Could not uniquely map market to one current-week game"})
            continue
        game = candidates[0]
        teams = {str(game.get("home_team", "")).upper(), str(game.get("away_team", "")).upper()}
        season_for_game = int(game.get("season")) if game.get("season") is not None else int(games.iloc[0]["season"])
        week_for_game = int(game.get("week")) if game.get("week") is not None else int(games.iloc[0]["week"])
        players = player_frame_from_sources(data, season_for_game, week_for_game, teams)
        match = find_player_match(market, players, game)
        if match:
            status, status_source = status_for_player(match["player_id"], match.get("team"), rosters, injuries)
        else:
            status, status_source = "UNKNOWN", "Player identity not matched exactly"
        predicted = predict_market(market, match, player_games, status)
        predicted.update({"game_id": str(game.get("game_id")), "home_team": game.get("home_team"),
                          "away_team": game.get("away_team"), "kickoff_local": str(game.get("kickoff_local")),
                          "status_source": status_source, "event_title": market.get("event_title", "")})
        game_markets.append(predicted)
        if match and market.get("category") in {"PASSING", "RUSHING", "RECEIVING", "SCORING", "DEFENSIVE"}:
            predictions.append(predicted)
        if not match:
            unmatched.append({"ticker": market.get("ticker"), "title": market.get("title"),
                              "reason": "Player name did not uniquely match current-season NFL player data"})
    return game_markets, predictions, unmatched


def run_analysis(refresh_markets_only=False):
    old = st.session_state.analysis
    if refresh_markets_only and old.get("data") and not old.get("games", pd.DataFrame()).empty:
        data, games, pg = old["data"], old["games"], old["player_games"]
        historical_games = old.get("historical_games", pd.DataFrame())
        core_errors, nfl_diag = {}, old.get("nfl_diagnostics", {})
    else:
        loaded = load_core_data()
        data, core_errors, nfl_diag = loaded["data"], loaded["errors"], loaded["diagnostics"]
        if "schedule" not in data:
            st.session_state.analysis = {**old, "data": data, "diagnostics": {"nfl_errors": core_errors, "nfl_sources": nfl_diag,
                                         "message": "NFL schedule unavailable; current official week cannot be determined"}}
            return
        schedule_df = normalize_schedule(data["schedule"])
        season, week, games = current_season_week(schedule_df)
        if season is None or games.empty:
            st.session_state.analysis = {**old, "data": data, "nfl_diagnostics": nfl_diag,
                                         "diagnostics": {"errors": core_errors, "message": "No current/future regular-season week found"}}
            return
        st.session_state.analysis["season"], st.session_state.analysis["week"] = season, week
        stats = data.get("stats")
        pg = prepare_player_games(stats, season, data.get("snaps")) if stats is not None else pd.DataFrame()
        # Historical seasons are intentionally loaded only on the Backtesting page.
        # Live projections always use the current-season asset alone.
        historical_games = pd.DataFrame()
    season, week = st.session_state.analysis.get("season"), st.session_state.analysis.get("week")
    client = KalshiClient()
    markets, kalshi_diag = discover_current_week_markets(client, orderbooks=True)
    game_markets, predictions, unmatched = process_markets(markets, games, data, pg)
    diagnostics = {"nfl_errors": core_errors, "nfl_sources": nfl_diag, "kalshi": kalshi_diag,
                   "games": len(games), "markets_discovered": len(markets),
                   "markets_mapped_to_games": len(game_markets), "matched_player_props": len(predictions),
                   "current_week_roster_count": len(data.get("rosters", pd.DataFrame())[pd.to_numeric(data.get("rosters", pd.DataFrame()).get("season", pd.Series(dtype=float)), errors="coerce").eq(season) & pd.to_numeric(data.get("rosters", pd.DataFrame()).get("week", pd.Series(dtype=float)), errors="coerce").eq(week)]) if data.get("rosters") is not None and {"season","week"}.issubset(data.get("rosters").columns) else None,
                   "unmatched": unmatched, "player_games": len(pg),
                   "participation_verified": bool(pg.attrs.get("participation_verified", False))}
    run_id = save_run(season, week, game_markets, predictions, diagnostics,
                      status="COMPLETE WITH DATA LIMITATIONS", model_version=MODEL_VERSION)
    st.session_state.analysis = {"predictions": predictions, "game_markets": game_markets, "markets": markets,
                                 "games": games, "diagnostics": diagnostics, "data": data,
                                 "season": season, "week": week, "player_games": pg, "historical_games": historical_games,
                                 "run_at": datetime.now(timezone.utc).isoformat(),
                                 "nfl_diagnostics": nfl_diag, "run_id": run_id,
                                 "unmatched": unmatched}


# Sidebar navigation + manually triggered work only.
with st.sidebar:
    st.title("🏈 PROP EDGE")
    st.caption("Kalshi-only · Manual refresh · Current NFL week")
    pages = ["Weekly Games", "Game Analysis", "Best Edges", "Player Analysis", "Matchup Analysis",
             "Fantasy Projections", "Backtesting", "Diagnostics"]
    page = st.radio("NAVIGATION", pages, index=pages.index(st.session_state.get("page", "Weekly Games")) if st.session_state.get("page", "Weekly Games") in pages else 0)
    st.session_state.page = page
    st.divider()
    if st.button("▶ RUN WEEKLY ANALYSIS", type="primary", use_container_width=True):
        with st.spinner("Retrieving NFL data and Kalshi markets; calculating available projections…"):
            try:
                run_analysis(False); st.success("Analysis run saved")
            except Exception as exc:
                st.error(str(exc)); st.session_state.last_error = traceback.format_exc()
    if st.button("↻ REFRESH KALSHI MARKETS", use_container_width=True):
        with st.spinner("Refreshing current-week Kalshi market data…"):
            try:
                run_analysis(True); st.success("Market refresh saved")
            except Exception as exc:
                st.error(str(exc)); st.session_state.last_error = traceback.format_exc()
    state = st.session_state.analysis
    if state.get("run_at"):
        st.caption(f"Last run: {state['run_at'][:19].replace('T',' ')} UTC")
    st.caption(f"Model {MODEL_VERSION}")

state = st.session_state.analysis
games = state.get("games", pd.DataFrame())
all_props = state.get("game_markets", [])
predictions = state.get("predictions", [])


def show_game_header(g):
    away, home = g.get("away_team", "?"), g.get("home_team", "?")
    st.subheader(f"{away} @ {home}")
    kickoff = g.get("kickoff_local")
    st.caption(f"Kickoff: {kickoff} · Status: {g.get('status','UNKNOWN')} · All times in {LOCAL_TIMEZONE}")


def prop_table(rows):
    if not rows:
        st.info("No mapped player-prop markets for this section. Markets that failed strict game/player/contract matching are listed in Diagnostics.")
        return
    columns = ["player", "team", "position", "category", "title", "condition", "market_yes_probability",
               "model_yes_probability", "yes_edge_pp", "market_no_probability", "model_no_probability",
               "no_edge_pp", "yes_ask", "no_ask", "yes_ev_before_fees", "no_ev_before_fees",
               "yes_roi_before_fees", "no_roi_before_fees", "positive_edge_side", "best_edge_pp",
               "average", "last5", "high", "hit_rate", "model_projection", "injury_status",
               "games", "volume_fp", "liquidity_dollars", "spread", "quote_timestamp", "recommendation_status"]
    df = pd.DataFrame(rows)
    cols = [c for c in columns if c in df.columns]
    view = df[cols].copy()
    rename = {"market_yes_probability":"Kalshi YES", "model_yes_probability":"Model YES", "yes_edge_pp":"YES EDGE (PP)",
              "market_no_probability":"Kalshi NO", "model_no_probability":"Model NO", "no_edge_pp":"NO EDGE (PP)",
              "average":"Season Avg", "last5":"Last 5 Avg", "high":"Season High", "hit_rate":"Exact-line Hit Rate",
              "model_projection":"Projection", "injury_status":"Injury", "games":"Games", "title":"Market",
              "yes_ask":"YES Ask", "no_ask":"NO Ask", "yes_ev_before_fees":"YES EV / Contract",
              "no_ev_before_fees":"NO EV / Contract", "yes_roi_before_fees":"YES ROI", "no_roi_before_fees":"NO ROI",
              "positive_edge_side":"Positive Edge Side", "best_edge_pp":"Best Edge (PP)"}
    view = view.rename(columns=rename)
    for c in ("Kalshi YES", "Model YES", "Kalshi NO", "Model NO", "Exact-line Hit Rate"):
        if c in view: view[c] = view[c].apply(fmt_pct)
    for c in ("YES EDGE (PP)", "NO EDGE (PP)", "Best Edge (PP)"):
        if c in view: view[c] = view[c].apply(fmt_edge)
    for c in ("YES Ask", "NO Ask"):
        if c in view: view[c] = view[c].apply(fmt_pct)
    for c in ("YES ROI", "NO ROI"):
        if c in view: view[c] = view[c].apply(fmt_pct)
    for c in ("YES EV / Contract", "NO EV / Contract"):
        if c in view: view[c] = view[c].apply(lambda x: fmt_num(x, 3))
    for c in ("Season Avg", "Last 5 Avg", "Season High", "Projection"):
        if c in view: view[c] = view[c].apply(fmt_num)
    st.dataframe(view, use_container_width=True, hide_index=True, height=min(650, 110+len(view)*38))
    for r in rows:
        label = f"{r.get('player') or 'Unmatched player'} · {r.get('title','Market')} · {fmt_edge(r.get('yes_edge_pp'))}"
        with st.expander(label):
            c1,c2,c3,c4 = st.columns(4)
            c1.metric("Kalshi YES midpoint", fmt_pct(r.get("market_yes_probability")))
            c2.metric("Model YES", fmt_pct(r.get("model_yes_probability")))
            c3.metric("YES EDGE (PP)", fmt_edge(r.get("yes_edge_pp")))
            c4.metric("Projection", fmt_num(r.get("model_projection")))
            st.write(f"**Positive probability edge side:** {r.get('positive_edge_side') or 'None'} · **Best edge:** {fmt_edge(r.get('best_edge_pp'))}")
            st.write(f"**YES settlement:** {r.get('condition','unparsed')} · **Model status:** {r.get('prediction_status','Unavailable')}")
            st.write(f"**Current-season sample:** {r.get('cleared','—')} / {r.get('games','—')} cleared; hit rate {fmt_pct(r.get('hit_rate'))}. Sample completeness: {r.get('sample_complete',False)}")
            if r.get("games") and r.get("cleared") == 0:
                st.warning(f"0 / {r.get('games')} GAMES CLEARED this season for this exact condition.")
            st.write(f"**Recent:** season {fmt_num(r.get('average'))}, L3 {fmt_num(r.get('last3'))}, L5 {fmt_num(r.get('last5'))}, L10 {fmt_num(r.get('last10'))}, high {fmt_num(r.get('high'))}.")
            st.write(f"**Usage:** expected opportunities {fmt_num(r.get('expected_opportunities'))}; efficiency {fmt_num(r.get('expected_efficiency'),3)}.")
            st.write(f"**Status:** {r.get('injury_status','UNKNOWN')} — {r.get('status_source','')}")
            st.write(f"**Market:** bid {fmt_pct(r.get('yes_bid'))}, ask {fmt_pct(r.get('yes_ask'))}, spread {fmt_pct(r.get('spread'))}; quote {r.get('quote_label','')}; retrieved {r.get('quote_timestamp','unknown')}.")
            st.write(f"**EV before fees:** YES {fmt_num(r.get('yes_ev_before_fees'),3)} / ROI {fmt_pct(r.get('yes_roi_before_fees'))}; NO {fmt_num(r.get('no_ev_before_fees'),3)} / ROI {fmt_pct(r.get('no_roi_before_fees'))}.")
            st.write("**What could make this wrong:** limited current-season sample, unverified participation for zero-stat games, changing player role, or injury information that has not appeared in the available feed. Opponent and game-script effects are not applied unless supported by a validated data table.")
            st.caption("The baseline ensemble is an experimental foundation, not yet validated or calibrated. Matchup, injury redistribution and game-script layers remain neutral/unavailable unless their inputs are actually verified.")


st.title("🏈 NFL PROP EDGE ENGINE")
st.caption("Kalshi-only player prop research · No automated trading · Model edges are not guarantees")
if state.get("season"):
    st.caption(f"Current official schedule selection: {state['season']} · Week {state['week']} · Model {MODEL_VERSION}")

if page == "Weekly Games":
    st.header("WEEKLY NFL GAMES")
    if games.empty:
        st.info("Press RUN WEEKLY ANALYSIS to retrieve the current official NFL schedule, current-season player statistics, rosters and Kalshi markets. The app does not use sample/demo data.")
        if state.get("diagnostics"):
            st.json(state["diagnostics"])
    else:
        pcount = {}
        for p in all_props: pcount[str(p.get("game_id"))] = pcount.get(str(p.get("game_id")),0)+1
        st.write(f"{len(games)} games · {sum(pcount.values())} game-mapped player markets")
        for _, g in games.iterrows():
            away, home = g.get("away_team"), g.get("home_team")
            gid = str(g.get("game_id"))
            with st.container(border=True):
                left, mid, right = st.columns([3,2,1])
                left.markdown(f"### {away}  @  {home}")
                left.caption(f"{g.get('kickoff_local')} · {g.get('status')}")
                mid.metric("Mapped player markets", pcount.get(gid,0))
                if right.button("OPEN GAME →", key=f"open_{gid}", use_container_width=True):
                    st.session_state.selected_game = gid; st.session_state.page = "Game Analysis"; st.rerun()
        st.caption("A game card only receives a market when both teams are explicitly identifiable in the Kalshi event/market text. This intentionally favors avoiding false game assignments over guessing.")

elif page == "Game Analysis":
    st.header("INDIVIDUAL GAME ANALYSIS")
    if games.empty:
        st.info("Run Weekly Analysis first.")
    else:
        options = {f"{r.away_team} @ {r.home_team} — Week {r.week}": str(r.game_id) for r in games.itertuples()}
        labels = list(options)
        default_index = next((i for i, v in enumerate(options.values()) if v == st.session_state.selected_game), 0)
        chosen = st.selectbox("Select matchup", labels, index=default_index)
        gid = options[chosen]; st.session_state.selected_game = gid
        g = games[games.game_id.astype(str) == gid].iloc[0].to_dict(); show_game_header(g)
        if st.button("← BACK TO WEEKLY GAMES"):
            st.session_state.page = "Weekly Games"
            st.rerun()
        selected = [r for r in all_props if str(r.get("game_id")) == gid]
        st.metric("Player-prop markets mapped to game", len(selected))
        if not selected:
            st.warning("No Kalshi markets could be uniquely associated with this matchup. See Diagnostics for markets that could not be safely matched.")
        for category in ("PASSING", "RUSHING", "RECEIVING", "SCORING", "DEFENSIVE", "SPECIAL", "OTHER / UNCLASSIFIED"):
            key = "OTHER" if category == "OTHER / UNCLASSIFIED" else category
            subset = [r for r in selected if r.get("category") == key]
            with st.expander(f"{category} PROPS ({len(subset)})", expanded=(category in {"PASSING","RUSHING","RECEIVING"})):
                prop_table(subset)
        st.subheader("Injury / roster availability")
        statuses = pd.DataFrame([{k:r.get(k) for k in ("player","team","injury_status","status_source")} for r in selected if r.get("player")])
        if not statuses.empty: st.dataframe(statuses.drop_duplicates(), use_container_width=True, hide_index=True)
        else: st.caption("No player injury status could be verified from the available feed.")

elif page == "Best Edges":
    st.header("THIS WEEK'S MODEL EDGES")
    if not predictions: st.info("Run Weekly Analysis to populate current-week player props.")
    else:
        view = st.radio("View", ["Positive edges (YES or NO)", "Negative YES edges", "All markets"], horizontal=True)
        rows = [p for p in predictions if p.get("yes_edge_pp") is not None]
        if view == "Positive edges (YES or NO)": rows = [p for p in rows if (p.get("best_edge_pp") or 0) > 0]
        elif view == "Negative YES edges": rows = [p for p in rows if p.get("yes_edge_pp", 0) < 0]
        sort = st.selectbox("Sort", ["Highest positive edge", "Most negative YES edge", "Highest expected value", "Highest model probability", "Player name", "Prop category", "Liquidity"])
        keys = {"Highest positive edge": lambda x:x.get("best_edge_pp",-999), "Most negative YES edge":lambda x:x.get("yes_edge_pp",999),
                "Highest expected value":lambda x:x.get("best_ev_before_fees",-999) if x.get("best_ev_before_fees") is not None else -999,
                "Highest model probability":lambda x:x.get("model_yes_probability",-1) or -1,
                "Player name":lambda x:str(x.get("player","")), "Prop category":lambda x:str(x.get("category","")),
                "Liquidity":lambda x:float(x.get("liquidity_dollars") or 0)}
        rows = sorted(rows, key=keys[sort], reverse=sort not in {"Most negative YES edge", "Player name", "Prop category"})
        prop_table(rows)
        st.caption("NO edge is the exact complement of YES edge. Negative edges are retained and visible.")

elif page == "Player Analysis":
    st.header("PLAYER ANALYSIS")
    players = sorted({str(p.get("player")) for p in predictions if p.get("player")})
    if not players: st.info("Run analysis and match a player prop before player details can be shown.")
    else:
        selected = st.selectbox("Player", players)
        rows = [p for p in predictions if p.get("player") == selected]
        st.subheader(selected)
        st.dataframe(pd.DataFrame([{k:r.get(k) for k in ("team","position","category","title","average","last3","last5","last10","high","low","games","hit_rate","model_projection","model_yes_probability","yes_edge_pp","injury_status")} for r in rows]), use_container_width=True, hide_index=True)
        pg = state.get("player_games", pd.DataFrame())
        pid = next((r.get("player_id") for r in rows if r.get("player_id")), None)
        if pid and not pg.empty:
            logs = pg[pg.player_id.astype(str) == str(pid)].sort_values("week")
            st.subheader("Current-season game log")
            st.dataframe(logs, use_container_width=True, hide_index=True)
            stat_choice = st.selectbox("Chart statistic", [c for c in ("passing_yards","rushing_yards","receiving_yards","receptions","targets","attempts","carries") if c in logs.columns])
            st.plotly_chart(px.line(logs, x="week", y=stat_choice, markers=True, title=f"{selected} — {stat_choice}"), use_container_width=True)

elif page == "Matchup Analysis":
    st.header("MATCHUP ANALYSIS")
    if games.empty: st.info("Run Weekly Analysis first.")
    else:
        choices = {f"{r.away_team} @ {r.home_team}":str(r.game_id) for r in games.itertuples()}
        label = st.selectbox("Matchup", list(choices)); gid = choices[label]
        g = games[games.game_id.astype(str)==gid].iloc[0].to_dict(); show_game_header(g)
        rows = [p for p in all_props if str(p.get("game_id"))==gid]
        st.write(f"Mapped market count: {len(rows)}")
        st.info("Opponent-specific EPA, positional defense, current injuries on both teams, and Kalshi game spread/total feeds are not yet validated in this initial codebase. No unsupported matchup or blowout adjustment is applied.")
        if rows: prop_table(rows)

elif page == "Fantasy Projections":
    st.header("FANTASY PROJECTIONS")
    if not predictions: st.info("Run Weekly Analysis first.")
    else:
        mode = st.selectbox("Scoring", ["Standard", "Half-PPR", "Full-PPR", "Custom"])
        scoring = ppr_scoring(mode)
        if mode == "Custom":
            a, b, c, d = st.columns(4)
            scoring["pass_yards"] = a.number_input("Passing yards / point", min_value=0.0, max_value=1.0, value=.04, step=.01, format="%.2f")
            scoring["pass_td"] = b.number_input("Passing TD", min_value=0.0, max_value=10.0, value=4.0, step=.5)
            scoring["interception"] = c.number_input("Interception", min_value=-10.0, max_value=0.0, value=-2.0, step=.5)
            scoring["reception"] = d.number_input("Reception", min_value=0.0, max_value=2.0, value=1.0, step=.5)
            a, b, c, d = st.columns(4)
            scoring["rush_yards"] = a.number_input("Rushing yards / point", min_value=0.0, max_value=1.0, value=.1, step=.01, format="%.2f")
            scoring["rush_td"] = b.number_input("Rushing TD", min_value=0.0, max_value=10.0, value=6.0, step=.5)
            scoring["rec_yards"] = c.number_input("Receiving yards / point", min_value=0.0, max_value=1.0, value=.1, step=.01, format="%.2f")
            scoring["rec_td"] = d.number_input("Receiving TD", min_value=0.0, max_value=10.0, value=6.0, step=.5)
        grouped = {}
        stat_by_key = {"PASSING":"passing_yards", "RUSHING":"rushing_yards", "RECEIVING":"receiving_yards"}
        for p in predictions:
            pid = p.get("player_id")
            if not pid: continue
            bucket = grouped.setdefault(pid, {"player":p.get("player"),"team":p.get("team")})
            stat = p.get("stat_key"); projection = p.get("model_projection")
            if stat and projection is not None: bucket[stat] = projection
        rows=[]
        for p in grouped.values():
            p["fantasy_points"] = fantasy_points(p, scoring); rows.append(p)
        if rows: st.dataframe(pd.DataFrame(rows).sort_values("fantasy_points", ascending=False), use_container_width=True, hide_index=True)
        st.caption("Fantasy totals are partial when only a subset of a player's prop-stat projections has been matched. Missing stats are not assumed to be zero.")

elif page == "Backtesting":
    st.header("PLAYER PROJECTION BACKTESTING")
    st.caption(
        "This page evaluates numeric player-stat projections against actual NFL results. "
        "Kalshi odds, market probabilities, contract prices, edges, and betting returns "
        "are not inputs to this backtest."
    )
    pg = state.get("historical_games", pd.DataFrame())
    if pg.empty:
        if st.button("LOAD HISTORICAL PLAYER GAMES & TEST PROJECTIONS", type="primary"):
            season_end = int(state.get("season") or datetime.now(timezone.utc).year)
            try:
                with st.spinner(
                    f"Loading season-specific player-stat files from {BACKTEST_START_SEASON} through {season_end}…"
                ):
                    hist_client = NFLVerseClient()
                    historical_stats = hist_client.load_historical_player_stats(BACKTEST_START_SEASON, season_end)
                    pg = prepare_historical_player_games(historical_stats, state.get("data", {}).get("snaps"))
                    st.session_state.analysis["historical_games"] = pg
                    st.session_state.analysis.setdefault("nfl_diagnostics", {}).update(hist_client.diagnostics)
                    st.session_state.analysis["historical_stats_seasons"] = historical_stats.attrs.get("seasons_loaded", [])
                    st.session_state.historical_load_error = None
                if pg.empty:
                    st.warning("Historical files were retrieved, but no usable player-game rows could be built.")
                else:
                    summary, detail = run_stat_backtest(pg)
                    st.session_state.backtest_summary = summary
                    st.session_state.backtest_detail = detail
            except Exception as exc:
                st.session_state.historical_load_error = str(exc)
                st.error(f"Historical data load failed: {exc}")

        if st.session_state.get("historical_load_error"):
            st.warning(st.session_state.historical_load_error)
        if pg.empty:
            st.info(
                "Historical player-game data has not been loaded. Load it to compare forecasts "
                "with actual results. Older seasons are used only in this separate backtest, "
                "never in current-season player averages."
            )

    if not pg.empty:
        seasons_available = sorted(
            pd.to_numeric(pg.season, errors="coerce").dropna().astype(int).unique()
        ) if "season" in pg else []
        st.info(
            f"Projection-only, next-game walk-forward test. Seasons loaded: {seasons_available}. "
            "Every prediction uses only earlier games from the same player and same season. "
            "No sportsbook or Kalshi odds are read by this process."
        )
        min_history = st.slider("Minimum prior games required", min_value=2, max_value=8, value=3, step=1)
        if st.button("RUN PROJECTION ACCURACY BACKTEST", type="primary"):
            with st.spinner("Generating historical next-game projections and scoring them against actual results…"):
                summary, detail = run_stat_backtest(pg, min_history=min_history)
                st.session_state.backtest_summary = summary
                st.session_state.backtest_detail = detail
                st.session_state.backtest_min_history = min_history

        summary = st.session_state.get("backtest_summary")
        detail = st.session_state.get("backtest_detail")
        if summary is not None and not summary.empty:
            if detail is not None and not detail.empty:
                m1, m2, m3, m4 = st.columns(4)
                m1.metric("Out-of-sample forecasts", f"{detail[['player_id','season','week','stat']].drop_duplicates().shape[0]:,}")
                m2.metric("Player-stat combinations", f"{detail.stat.nunique():,}")
                m3.metric("Seasons tested", f"{detail.season.nunique():,}")
                m4.metric("Model variants", f"{detail.model.nunique():,}")

            st.subheader("Projection accuracy by statistic and model")
            view = summary.copy()
            season_options = ["ALL SEASONS"] + sorted(
                [int(v) for v in view.season.dropna().unique() if v != "ALL SEASONS"]
            )
            selected_season = st.selectbox("Results period", season_options, index=0)
            view = view[view.season.eq(selected_season)]
            display_cols = [
                "stat", "model", "n", "mae", "rmse", "bias", "median_absolute_error",
                "coverage_50_band", "coverage_80_band", "average_80_band_width",
                "skill_vs_season_average", "status",
            ]
            display = view[[c for c in display_cols if c in view.columns]].copy()
            display = display.rename(columns={
                "stat": "STAT", "model": "MODEL", "n": "N",
                "mae": "MAE", "rmse": "RMSE", "bias": "BIAS",
                "median_absolute_error": "MEDIAN ABS ERROR",
                "coverage_50_band": "50% BAND COVERAGE",
                "coverage_80_band": "80% BAND COVERAGE",
                "average_80_band_width": "AVG 80% BAND WIDTH",
                "skill_vs_season_average": "SKILL VS SEASON AVG",
                "status": "STATUS",
            })
            st.dataframe(display, use_container_width=True, hide_index=True)
            st.caption(
                "MAE/RMSE are in the statistic's native units. Positive skill vs season average means "
                "lower MAE than the simple prior-season-average baseline on the same test rows. "
                "Prediction bands are empirical historical-variation ranges, not calibrated confidence intervals."
            )

            if detail is not None and not detail.empty:
                st.download_button(
                    "Download projection backtest rows CSV",
                    detail.to_csv(index=False),
                    "nfl_projection_backtest.csv",
                    "text/csv",
                )
                stats_available = sorted(detail.stat.dropna().unique())
                selected_stat = st.selectbox("Statistic chart", stats_available)
                chart = detail[detail.stat.eq(selected_stat)].copy()
                st.plotly_chart(
                    px.scatter(
                        chart, x="actual", y="predicted", color="model",
                        hover_data=["player_id", "season", "week", "prior_games", "error"],
                        title=f"{selected_stat.replace('_', ' ').title()}: projected vs actual",
                    ).add_shape(
                        type="line", x0=0, y0=0,
                        x1=float(max(chart.actual.max(), chart.predicted.max(), 1)),
                        y1=float(max(chart.actual.max(), chart.predicted.max(), 1)),
                        line={"dash": "dash", "color": "white"},
                    ),
                    use_container_width=True,
                )
                all_stat_summary = summary[(summary.season == "ALL SEASONS") & summary.stat.eq(selected_stat)].copy()
                if not all_stat_summary.empty:
                    st.plotly_chart(
                        px.bar(
                            all_stat_summary.sort_values("mae"), x="model", y="mae",
                            title=f"{selected_stat.replace('_', ' ').title()}: mean absolute projection error (lower is better)",
                        ),
                        use_container_width=True,
                    )
                with st.expander("What these results mean"):
                    st.markdown(
                        "- **MAE:** average absolute difference between projected and actual player production.\n"
                        "- **RMSE:** penalizes large misses more heavily.\n"
                        "- **Bias:** positive means the model overprojected on average; negative means it underprojected.\n"
                        "- **Band coverage:** percentage of actual performances inside the empirical 50% or 80% forecast range.\n"
                        "- **Skill vs season average:** compares each model with a simple prior-game average baseline.\n\n"
                        "No market lines or odds are required for these metrics. Brier score, log loss, edge, and ROI "
                        "are intentionally omitted because they require historical binary lines/probabilities or prices."
                    )
        else:
            st.caption("No projection backtest has been run in this session.")

elif page == "Diagnostics":
    st.header("DATA DIAGNOSTICS")
    d = state.get("diagnostics", {})
    if not d: st.info("Run Weekly Analysis to test source connections.")
    else:
        c1,c2,c3,c4 = st.columns(4)
        c1.metric("Current-week games", d.get("games",0)); c2.metric("Markets discovered", d.get("markets_discovered",0))
        c3.metric("Mapped player props", d.get("matched_player_props",0)); c4.metric("Unmatched markets", len(d.get("unmatched",[])))
        st.subheader("NFL data source status")
        st.json({"NFL source errors":d.get("nfl_errors",{}),"NFL release diagnostics":d.get("nfl_sources",{})})
        st.subheader("Kalshi discovery")
        st.json(d.get("kalshi",{}))
        st.subheader("Quality checks")
        st.write(f"Player-game rows loaded: {d.get('player_games',0)}")
        st.write(f"Participation verified through snap-count merge: {d.get('participation_verified',False)}")
        st.write("Backtesting evaluates player-stat projections against actual player results. Historical Kalshi prices and ROI are not used in the projection backtest.")
        if d.get("unmatched"):
            st.subheader("Unmatched / unvalidated markets")
            st.dataframe(pd.DataFrame(d["unmatched"]), use_container_width=True, hide_index=True)
        if st.session_state.get("last_error"):
            with st.expander("Last runtime traceback"): st.code(st.session_state.last_error)
        history = load_run_history()
        if history:
            st.subheader("Saved analysis runs")
            st.dataframe(pd.DataFrame([{k:r[k] for k in ("run_id","created_at","season","week","status")} for r in history]), use_container_width=True, hide_index=True)

st.divider()
st.caption("Data and model limitations are shown explicitly. No live trade execution exists. Market probability is a quote midpoint, not a guaranteed fill price; expected value is shown before fees.")
