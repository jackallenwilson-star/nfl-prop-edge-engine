"""Player identity assembly with current-season filter and ID-first records."""
import pandas as pd


def build_current_player_database(stats: pd.DataFrame, players: pd.DataFrame | None,
                                  season: int, rosters: pd.DataFrame | None = None) -> pd.DataFrame:
    if stats is None or stats.empty: return pd.DataFrame()
    x = stats[pd.to_numeric(stats.season, errors="coerce").eq(int(season))].copy()
    idc = next((c for c in ("player_id", "gsis_id") if c in x.columns), None)
    namec = next((c for c in ("player_display_name", "player_name", "display_name") if c in x.columns), None)
    if not idc or not namec: return pd.DataFrame()
    teamc = next((c for c in ("recent_team", "team") if c in x.columns), None)
    cols = [idc, namec] + ([teamc] if teamc else []) + (["position"] if "position" in x else [])
    out = x[cols].dropna(subset=[idc, namec]).drop_duplicates(idc, keep="last").copy()
    out = out.rename(columns={idc:"player_id", namec:"player_name"})
    if teamc: out = out.rename(columns={teamc:"team"})
    if players is not None and not players.empty:
        p_id = next((c for c in ("gsis_id", "player_id") if c in players.columns), None)
        if p_id:
            selected = [p_id] + [c for c in ("position", "birth_date", "height", "weight", "college") if c in players]
            extra = players[selected].drop_duplicates(p_id).rename(columns={p_id:"player_id"})
            out = out.merge(extra, on="player_id", how="left", suffixes=("", "_identity"))
    if rosters is not None and not rosters.empty and {"season","week"}.issubset(rosters.columns):
        rid = next((c for c in ("gsis_id", "player_id") if c in rosters.columns), None)
        team = next((c for c in ("team", "recent_team") if c in rosters.columns), None)
        if rid:
            active_ids = rosters[rosters.season.astype(str).eq(str(season))]
            active_ids = active_ids[rid].astype(str).unique()
            out["listed_on_season_roster"] = out.player_id.astype(str).isin(active_ids)
    return out
