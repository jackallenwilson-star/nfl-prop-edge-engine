"""Conservative Kalshi player-prop classification and YES-condition parsing."""
from __future__ import annotations
import re

CATEGORY_KEYWORDS = {
    "PASSING": ("passing yards", "pass yards", "pass attempts", "passing attempts", "completions", "passing touchdowns", "passing td", "interceptions thrown", "longest completion"),
    "RUSHING": ("rushing yards", "rush yards", "rushing attempts", "rush attempts", "carries", "rushing touchdowns", "rushing td", "longest rush"),
    "RECEIVING": ("receiving yards", "rec yards", "receptions", "receiving touchdowns", "receiving td", "longest reception"),
    "SCORING": ("anytime touchdown", "first touchdown", "first td", "multiple touchdowns", "to score a touchdown", "2+ touchdowns"),
    "DEFENSIVE": ("tackles", "sacks", "interceptions", "passes defended", "defensive touchdowns"),
}
STAT_ALIASES = {
    "passing_yards": ("passing yards", "pass yards"),
    "passing_tds": ("passing touchdowns", "passing td", "pass tds"),
    "attempts": ("passing attempts", "pass attempts"),
    "completions": ("completions",),
    "interceptions": ("interceptions thrown", "interceptions"),
    "rushing_yards": ("rushing yards", "rush yards"),
    "carries": ("rushing attempts", "rush attempts", "carries"),
    "rushing_tds": ("rushing touchdowns", "rushing td"),
    "receiving_yards": ("receiving yards", "rec yards"),
    "receptions": ("receptions",),
    "receiving_tds": ("receiving touchdowns", "receiving td"),
    "sacks": ("sacks",),
    "tackles": ("tackles",),
}


def market_text(market: dict) -> str:
    keys = ("title", "subtitle", "yes_sub_title", "yes_subtitle", "no_sub_title", "no_subtitle", "rules_primary", "rules_secondary")
    return " | ".join(str(market.get(k, "")) for k in keys if market.get(k) is not None)


def classify_market(market: dict) -> tuple[str, str | None, str]:
    text = market_text(market).lower()
    title = str(market.get("title", "")).lower()
    special = any(w in text for w in ("ladder", "slingshot", "escalator", "multivariate", "multiple outcomes"))
    if special: return "SPECIAL", None, "SPECIAL PAYOUT / NON-BINARY"
    game_level_terms = ("moneyline", "spread", "point spread", "game total", "total points", "team total",
                        "win the game", "wins the game", "game winner", "margin of victory")
    if any(w in text for w in game_level_terms): return "GAME_LEVEL", None, "GAME MARKET — CONTEXT ONLY"
    future_terms = ("season-long", "season total", "season leader", "most valuable player", "mvp", "super bowl champion", "division winner", "conference champion")
    if any(w in text for w in future_terms):
        return "FUTURE", None, "FUTURE EXCLUDED"
    for category, terms in CATEGORY_KEYWORDS.items():
        for term in terms:
            if term in text:
                stat = next((s for s, aliases in STAT_ALIASES.items() if term in aliases), None)
                if category == "DEFENSIVE":
                    if term == "interceptions": stat = "def_interceptions"
                    elif term == "passes defended": stat = "passes_defended"
                    elif term == "sacks": stat = "sacks"
                    elif term == "tackles": stat = "tackles"
                if category == "PASSING" and term == "interceptions thrown": stat = "interceptions"
                if category == "SCORING":
                    stat = "anytime_td" if "anytime" in text or "to score" in text else "first_td" if "first touchdown" in text else "td_count"
                return category, stat, "STANDARD CANDIDATE"
    return "OTHER", None, "UNCLASSIFIED"


def parse_yes_condition(market: dict) -> dict:
    """Parse only unambiguous textual YES conditions; return unavailable otherwise."""
    text = market_text(market).lower()
    # Structured strike metadata is useful only when a corresponding direction is explicit.
    threshold = market.get("floor_strike")
    if threshold is None: threshold = market.get("cap_strike")
    plus_match = re.search(r"(?<![a-z0-9])(\d+(?:\.\d+)?)\s*\+", text)
    if plus_match:
        value = float(plus_match.group(1))
        return {"operator": ">=", "threshold": value, "condition": f">= {value:g}", "parse_status": "PARSED"}
    or_more = re.search(r"(?<![a-z0-9])(\d+(?:\.\d+)?)\s+or more", text)
    if or_more:
        value = float(or_more.group(1))
        return {"operator": ">=", "threshold": value, "condition": f">= {value:g}", "parse_status": "PARSED"}
    patterns = [
        (r"\b(at least|no less than)\s*\$?\s*(-?\d+(?:\.\d+)?)", ">="),
        (r"\b(over|more than|greater than|above)\s*\$?\s*(-?\d+(?:\.\d+)?)", ">"),
        (r"\b(under|less than|fewer than|below)\s*\$?\s*(-?\d+(?:\.\d+)?)", "<"),
        (r"\b(at most|no more than)\s*\$?\s*(-?\d+(?:\.\d+)?)", "<="),
        (r"\b(exactly|equal to)\s*\$?\s*(-?\d+(?:\.\d+)?)", "=="),
    ]
    for pattern, operator in patterns:
        match = re.search(pattern, text)
        if match:
            try:
                value = float(match.group(2))
                return {"operator": operator, "threshold": value, "condition": f"{operator} {value:g}", "parse_status": "PARSED"}
            except (ValueError, IndexError):
                continue
    # A clearly formatted numeric range is not a single binary outcome.
    if any(x in text for x in ("at least", "over", "more than", "under", "less than", "exactly", "+")) and threshold is not None:
        for op in (">=", ">", "<", "<=", "=="):
            if op in text:
                try: return {"operator": op, "threshold": float(threshold), "condition": f"{op} {float(threshold):g}", "parse_status": "PARSED"}
                except (TypeError, ValueError): pass
    return {"operator": None, "threshold": None, "condition": "UNPARSED YES SETTLEMENT", "parse_status": "UNAVAILABLE"}


def normalize_market(market: dict) -> dict:
    category, stat, kind = classify_market(market)
    condition = parse_yes_condition(market)
    row = dict(market)
    row.update({"category": category, "stat_key": stat, "market_kind": kind, **condition})
    if category in ("FUTURE", "OTHER", "GAME_LEVEL"):
        row["actionable_validation"] = "EXCLUDED / CONTEXT ONLY / UNCLASSIFIED"
    elif category == "SPECIAL":
        row["actionable_validation"] = "SPECIAL CONTRACT — separate pricing required"
    elif not condition["parse_status"] == "PARSED":
        row["actionable_validation"] = "YES CONDITION UNVERIFIED"
    else:
        row["actionable_validation"] = "STANDARD BINARY CANDIDATE"
    return row
