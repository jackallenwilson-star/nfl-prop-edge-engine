# NFL Prop Edge Engine

A Replit-ready, Streamlit research dashboard for current-week NFL player props using **Kalshi only** and current-season nflverse data. The app does not place trades and does not require Kalshi credentials for ordinary public market retrieval.

## Run it in Replit

1. Create a new **Python** Repl.
2. Upload the ZIP contents (or import this project from GitHub) so `app.py`, `requirements.txt`, and the other modules are at the project root.
3. In the Replit Shell, run:

   ```bash
   pip install -r requirements.txt
   streamlit run app.py --server.address 0.0.0.0 --server.port 3000
   ```

4. Open the Replit web preview. Press **RUN WEEKLY ANALYSIS** in the sidebar. The app does not continuously poll data.

The included `.replit` file configures the run command for Replit deployments that honor it. In the workspace Shell, use Python 3.11 or newer. Replit's free plan and any hosting provider have resource and usage limits; this project is not an unlimited-compute service.

## Data sources

### Kalshi

The app uses the public read-only Kalshi Trade API base URL:

`https://external-api.kalshi.com/trade-api/v2`

It discovers series from the API, inspects series metadata for NFL/football, retrieves open events and their nested markets where supported, and queries markets within discovered series. Market quote fields are normalized to dollar prices; legacy cent fields are converted only when dollar fields are absent. YES asks can be derived from NO bids and NO asks from YES bids. It attempts order-book retrieval for a capped number of markets and falls back to market quote fields if an order-book request is unavailable. Kalshi is the exclusive prediction-market source; the app does not substitute sportsbook odds.

Public market retrieval does not require trading keys. Order-book availability can differ by API access/response. The app does not submit orders.

### NFL data

The app inspects GitHub release metadata from `nflverse/nflverse-data`, chooses data assets based on their actual names and validates actual columns before using them. It first loads the schedule and determines the current official season/week, then selects the exact season-specific weekly player-stat asset (`stats_player_week_{season}.csv` or a supported equivalent) from the `stats_player` release metadata. It loads weekly rosters, player identity, snap counts, and the matching season's injury release separately. The backtesting page loads a configurable historical range (`BACKTEST_START_SEASON`, default 2018) only when requested. Optional releases can be unavailable or have changed schemas; diagnostics show the result instead of inventing data.

nflverse notes that schedules update frequently, player and team stats update after game days, rosters update daily, and snap counts update several times per day. Its participation data from 2023 onward may not update during the season, so the app uses snap-count participation only when available and flags incomplete participation otherwise.

## What is implemented

- Streamlit dark dashboard with weekly games, game analysis, best edges, player analysis, matchup analysis, fantasy projections, backtesting, and diagnostics pages.
- Manual **RUN WEEKLY ANALYSIS** and **REFRESH KALSHI MARKETS** controls.
- Dynamic nflverse release-asset inspection with schema validation.
- Kalshi-only public market discovery, pagination, quote normalization, and optional order-book retrieval.
- Conservative player name matching and team/game matching. Ambiguous names or game assignments are left unmatched.
- Exact textual YES-condition parsing for basic Over/Under/at-least/at-most/exactly contracts. An unparseable contract does not receive a probability edge.
- Current-season player summaries, last 3/5/10, high/low, exact threshold hit rates, zero-stat rows when snap participation verifies a played game, and a completeness flag otherwise.
- Recent performance A/B candidates, workload x efficiency projection, current-season-only positional shrinkage, seeded probability simulation, exact settlement operators, YES/NO edges, and pre-fee expected value at executable asks.
- Injury status uses explicit feed information when available; absence from a feed does not imply healthy. Only an explicit ACTIVE status is treated as actionable.
- SQLite history for analysis runs, market snapshots, and predictions.
- A genuine chronological next-game statistical backtest using prior rows from the same player and same season only. Multi-season weekly stats are loaded separately on demand for backtesting. No historical Kalshi ROI is calculated because this build does not retrieve a verified historical Kalshi price/settlement history.
- Unit tests for price normalization, edge arithmetic, schedule selection, zero-stat participation, conservative player matching, formula calculations, simulation reproducibility, and projection-backtest leakage controls (including future-game invariance, inactive-row exclusion, zero-stat retention, usage calculations, and empirical bands).

## Important limitations in this foundation build

This is a working analytics foundation, **not a fully validated profitable model**. Model 1 and Model 2 form an experimental baseline ensemble. Models 3 (opponent defense), 4 (injury redistribution), and 5 (game script) are kept neutral/unavailable unless validated inputs exist. The current injury/roster sources may be unavailable or may not contain a complete official game-status feed. Team logos, weather, detailed official depth charts, full position-specific defense, multi-outcome settlement logic, touchdown-first-scorer probabilities, and actual historical Kalshi backtesting are not implemented as validated features.

The contract parser is deliberately conservative. It only models a YES condition when explicit text makes the threshold and operator clear. Markets whose game or player cannot be uniquely identified are listed in Diagnostics or omitted from game-specific analysis rather than guessed.

The schedule converter assumes nflverse `gametime` is Eastern Time and converts it to `LOCAL_TIMEZONE` (default America/Los_Angeles). If the upstream schedule schema or time convention changes, inspect the Diagnostics page and adjust `schedule.py`.

A current-week stats release may not yet have refreshed after a game. A zero row is counted only when a snap-count row verifies participation. Otherwise the game-log sample is marked incomplete, and no missing player-stat row is silently interpreted as a zero.

## Interpreting outputs

- **Market probability** is the midpoint of verified current YES bid/ask quotes. It is not a guaranteed execution price.
- **YES/NO edge (PP)** is model probability minus midpoint market probability, in percentage points. Complementary YES and NO edges are equal and opposite.
- **Expected value** uses the actual YES or NO ask when available and is explicitly before fees. The app does not assume an unavailable fee schedule.
- **Model confidence** on the live market pages is not a calibrated probability confidence interval. Projection accuracy is evaluated separately on the Backtesting page; that evaluation does not itself prove profitable Kalshi edges.
- **0/N cleared** is the player's current-season observed hit count against that contract's exact parsed threshold, not a prediction on its own.
- **UNKNOWN injury status** is not treated as active or healthy and cannot be a recommendation.

## Backtesting

Open Backtesting and click **LOAD HISTORICAL PLAYER GAMES & TEST PROJECTIONS**. This requests season-specific weekly player-stat assets from `BACKTEST_START_SEASON` (default 2018) through the selected current season and creates a separate historical panel. Then click **RUN PROJECTION ACCURACY BACKTEST**. For a forecast of a player's Week W statistic, the model uses only that player's earlier games from the same season. Older seasons are not mixed into a current-season player average, and no future game can affect an earlier forecast.

The test compares five numeric forecasts: prior season average, recent Formula A, recent Formula B, usage x efficiency, and a candidate ensemble. It reports: **MAE** (typical absolute miss in the stat's native units), **RMSE** (penalizes large misses), **bias** (positive means overprojection), **median absolute error**, empirical 50%/80% range coverage, and skill versus the season-average baseline. Results can be filtered by season, plotted as actual vs projected, and exported as CSV.

The empirical forecast bands are based on past within-season player-game variation and are not calibrated confidence intervals. This projection backtest does not use Kalshi odds, market probabilities, contract lines, execution prices, edge, or ROI. Brier score/log loss and betting returns are intentionally omitted unless separately verified historical contract labels/prices are added. The data download may take time and use storage because it loads multiple season files.

## Persistence

SQLite stores each run and prediction snapshot in `data/nfl_prop_edge.sqlite`. Replit's storage persistence can depend on deployment/workspace configuration. Download/export important database snapshots or use an external persistent database before relying on long-term records.

## Tests

```bash
pytest -q
```

## Troubleshooting

- If a dataset is unavailable, check Diagnostics for the release tag, selected asset, and expected columns. Current player-stat loading requires the season-specific weekly stats asset for the selected season.
- If Kalshi shows zero markets, inspect Kalshi discovery errors and verify that the current API still exposes the relevant open NFL series/events.
- If a game card has zero mapped props, this may mean market text does not explicitly identify both teams; the matching layer refuses to guess.
- If edges are unavailable, inspect the YES condition parser, quote freshness, current-season player sample size, and player-status evidence.
- If dependency installation fails, retry `pip install -r requirements.txt` in the Replit Shell and check that the Repl is using a supported Python 3.11+ runtime.

## Project structure

Core modules are separated by responsibility: `kalshi_api.py`, `nfl_data.py`, `schedule.py`, `market_parser.py`, `player_matching.py`, `features.py`, model modules, `database.py`, `backtesting.py`, and `app.py`. Each statistical component can be improved without rewriting the dashboard.
