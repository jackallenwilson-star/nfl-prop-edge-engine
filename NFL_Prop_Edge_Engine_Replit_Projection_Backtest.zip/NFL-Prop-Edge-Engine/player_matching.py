"""Exact-ID-first and conservative textual player/game matching."""
from __future__ import annotations
import re
import unicodedata
import pandas as pd
from config import TEAM_ALIASES


def norm(value: str) -> str:
    value = unicodedata.normalize("NFKD", str(value or "")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", " ", value).strip()


def team_alias_hit(text: str, team: str) -> bool:
    text_n = norm(text)
    aliases = TEAM_ALIASES.get(str(team).upper(), [str(team).lower()])
    for alias in aliases:
        a = norm(alias)
        if len(a) <= 3:
            if re.search(rf"(?<![a-z0-9]){re.escape(a)}(?![a-z0-9])", text_n): return True
        elif f" {a} " in f" {text_n} ": return True
    return False


def game_matches_market(game: dict, market: dict) -> bool:
    text = " ".join(str(market.get(k, "")) for k in ("title", "subtitle", "event_title", "event_ticker", "ticker", "rules_primary"))
    away, home = str(game.get("away_team", "")), str(game.get("home_team", ""))
    return bool(away and home and team_alias_hit(text, away) and team_alias_hit(text, home))


def find_player_match(market: dict, players: pd.DataFrame, game: dict | None = None) -> dict | None:
    if players is None or players.empty: return None
    name_col = next((c for c in ("player_display_name", "player_name", "display_name", "name") if c in players.columns), None)
    id_col = next((c for c in ("player_id", "gsis_id") if c in players.columns), None)
    if not name_col or not id_col: return None
    text = norm(" ".join(str(market.get(k, "")) for k in ("title", "subtitle", "event_title", "yes_sub_title", "rules_primary")))
    candidates = []
    for _, p in players.iterrows():
        name = norm(p.get(name_col, ""))
        if len(name) < 5: continue
        if re.search(rf"(?<![a-z0-9]){re.escape(name)}(?![a-z0-9])", text):
            team = str(p.get("recent_team", p.get("team", ""))).upper()
            if game and team not in {str(game.get("home_team", "")).upper(), str(game.get("away_team", "")).upper()}:
                continue
            candidates.append(p)
    if len(candidates) != 1: return None
    p = candidates[0]
    return {"player_id": str(p[id_col]), "player_name": str(p[name_col]),
            "team": str(p.get("recent_team", p.get("team", ""))).upper(),
            "position": str(p.get("position", "")), "gsis_id": str(p.get("gsis_id", p[id_col]))}
