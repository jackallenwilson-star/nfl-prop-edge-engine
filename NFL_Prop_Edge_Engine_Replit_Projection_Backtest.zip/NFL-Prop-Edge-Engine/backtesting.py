"""Projection-only, leakage-aware walk-forward backtesting.

This module deliberately does not import or read Kalshi prices, market odds,
contract edges, or betting returns. It evaluates numeric player-stat forecasts
against actual player-game results using only earlier games from the same
player and season.
"""
from __future__ import annotations

from collections.abc import Iterable
import numpy as np
import pandas as pd

from model_evaluation import regression_metrics

DEFAULT_STATS = [
    "passing_yards", "passing_tds", "completions", "attempts", "interceptions",
    "rushing_yards", "rushing_tds", "carries",
    "receiving_yards", "receptions", "receiving_tds", "targets",
]

# Opportunity fields used by the independent usage x efficiency candidate.
OPPORTUNITY_MAP = {
    "passing_yards": "attempts",
    "passing_tds": "attempts",
    "completions": "attempts",
    "interceptions": "attempts",
    "rushing_yards": "carries",
    "rushing_tds": "carries",
    "receiving_yards": "targets",
    "receptions": "targets",
    "receiving_tds": "targets",
}

MODEL_COLUMNS = [
    ("prediction_season_average", "SEASON AVERAGE"),
    ("prediction_formula_a", "RECENT FORMULA A"),
    ("prediction_formula_b", "RECENT FORMULA B"),
    ("prediction_usage", "USAGE MODEL"),
    ("prediction_ensemble", "ENSEMBLE CANDIDATE"),
]


def _clean_game_rows(games: pd.DataFrame, stat: str) -> pd.DataFrame:
    """Normalize ordering and remove duplicate player-game observations.

    Rows with unknown/missing target statistics are excluded; they are never
    converted to zero. The upstream player-game builder is responsible for
    including a zero only when an actual participation row verifies it.
    """
    if games is None or games.empty or stat not in games or "player_id" not in games or "week" not in games:
        return pd.DataFrame()

    x = games.copy()
    x["player_id"] = x["player_id"].astype(str)
    x["week"] = pd.to_numeric(x["week"], errors="coerce")
    x[stat] = pd.to_numeric(x[stat], errors="coerce")
    x = x.dropna(subset=["player_id", "week", stat]).copy()
    x["week"] = x["week"].astype(int)

    if "season" in x.columns:
        x["season"] = pd.to_numeric(x["season"], errors="coerce")
        x = x.dropna(subset=["season"]).copy()
        x["season"] = x["season"].astype(int)
    else:
        x["season"] = 0

    # Do not count an explicitly inactive row as a played game.
    if "participated" in x.columns:
        x = x[x["participated"].fillna(False).astype(bool)].copy()

    # Stats are weekly aggregates: prefer game_id when present, otherwise one
    # player observation per season/week. Stable sorting makes duplicate choice
    # deterministic across runs.
    sort_cols = [c for c in ("season", "week", "game_id", "player_id") if c in x.columns]
    x = x.sort_values(sort_cols, kind="mergesort")
    dedupe = ["player_id", "season"] + (["game_id"] if "game_id" in x.columns else ["week"])
    x = x.drop_duplicates(dedupe, keep="last")
    return x.sort_values(["season", "player_id", "week"], kind="mergesort").reset_index(drop=True)


def _recent_formula(history: np.ndarray, formula: str) -> float:
    """Apply the requested formula to prior observations only."""
    season_mean = float(np.mean(history))
    last10 = float(np.mean(history[-10:]))
    last5 = float(np.mean(history[-5:]))
    last3 = float(np.mean(history[-3:]))
    if formula == "A":
        return 0.40 * season_mean + 0.25 * last10 + 0.20 * last5 + 0.15 * last3
    return 0.40 * season_mean + 0.35 * last5 + 0.25 * last3


def _usage_projection(history_rows: pd.DataFrame, stat: str, history_values: np.ndarray) -> tuple[float | None, float | None, float | None]:
    """Estimate production from prior opportunity volume x prior efficiency."""
    opportunity_col = OPPORTUNITY_MAP.get(stat)
    if not opportunity_col or opportunity_col not in history_rows.columns:
        return None, None, None

    paired = pd.DataFrame({
        "production": pd.to_numeric(history_rows[stat], errors="coerce"),
        "opportunities": pd.to_numeric(history_rows[opportunity_col], errors="coerce"),
    }).dropna()
    paired = paired[paired["opportunities"] >= 0]
    if paired.empty:
        return None, None, None

    total_opportunities = float(paired["opportunities"].sum())
    if total_opportunities <= 0:
        return None, None, None

    efficiency = float(paired["production"].sum() / total_opportunities)
    season_opportunity_average = float(paired["opportunities"].mean())
    last5_opportunity_average = float(paired["opportunities"].tail(5).mean())
    expected_opportunities = 0.60 * last5_opportunity_average + 0.40 * season_opportunity_average
    projection = expected_opportunities * efficiency
    return float(projection), float(expected_opportunities), float(efficiency)


def _empirical_interval(projection: float, history: np.ndarray, stat: str) -> dict[str, float]:
    """Create forecast bands from prior-game residuals, without future data.

    Residuals are prior player-game values centered around the prior sample
    mean, then shifted to the candidate projection. This is a transparent
    empirical uncertainty band, not a calibrated confidence interval.
    """
    residuals = history - float(np.mean(history))
    quantiles = np.quantile(residuals, [0.10, 0.25, 0.75, 0.90]) + float(projection)
    # Count and yardage metrics cannot be negative.
    quantiles = np.maximum(0.0, quantiles)
    return {
        "p10": float(quantiles[0]),
        "p25": float(quantiles[1]),
        "p75": float(quantiles[2]),
        "p90": float(quantiles[3]),
    }


def walk_forward_player_stat(
    games: pd.DataFrame,
    stat: str,
    min_history: int = 3,
) -> pd.DataFrame:
    """Generate out-of-sample next-game stat projections for each player.

    For a forecast in week W, all features and uncertainty bands use only
    observed player games earlier than W in that same season. Prior seasons
    are intentionally not used as player priors because roles/teams change.
    """
    x = _clean_game_rows(games, stat)
    if x.empty:
        return pd.DataFrame()

    rows: list[dict] = []
    group_cols = ["player_id", "season"]

    for (player_id, season), group in x.groupby(group_cols, sort=True):
        group = group.sort_values("week", kind="mergesort").reset_index(drop=True)
        values = pd.to_numeric(group[stat], errors="coerce").to_numpy(dtype=float)

        for i in range(max(1, int(min_history)), len(group)):
            history = values[:i]
            actual = values[i]
            if len(history) < min_history or not np.isfinite(actual) or not np.isfinite(history).all():
                continue

            prior_rows = group.iloc[:i]
            season_average = float(np.mean(history))
            formula_a = _recent_formula(history, "A")
            formula_b = _recent_formula(history, "B")
            usage, expected_opportunities, efficiency = _usage_projection(prior_rows, stat, history)
            ensemble = (0.60 * formula_a + 0.40 * usage) if usage is not None else None

            predictions = {
                "prediction_season_average": season_average,
                "prediction_formula_a": formula_a,
                "prediction_formula_b": formula_b,
                "prediction_usage": usage,
                "prediction_ensemble": ensemble,
            }

            row = {
                "player_id": str(player_id),
                "season": int(season),
                "week": int(group.iloc[i]["week"]),
                "actual": float(actual),
                "prior_games": int(len(history)),
                "prior_season_average": season_average,
                "prior_last10_average": float(np.mean(history[-10:])),
                "prior_last5_average": float(np.mean(history[-5:])),
                "prior_last3_average": float(np.mean(history[-3:])),
                "expected_opportunities": expected_opportunities,
                "historical_efficiency": efficiency,
                "participation_verified": bool(
                    prior_rows.get("participation_verified", pd.Series(False, index=prior_rows.index)).all()
                ),
            }
            for col, prediction in predictions.items():
                row[col] = prediction
                if prediction is not None and np.isfinite(prediction):
                    band = _empirical_interval(float(prediction), history, stat)
                    for q, value in band.items():
                        row[f"{col}_{q}"] = value
                else:
                    for q in ("p10", "p25", "p75", "p90"):
                        row[f"{col}_{q}"] = np.nan
            rows.append(row)

    return pd.DataFrame(rows)


def _summary_row(valid: pd.DataFrame, stat: str, model: str, prediction_col: str, season: int | str) -> dict:
    metrics = regression_metrics(valid["actual"], valid[prediction_col])
    p10 = valid[f"{prediction_col}_p10"]
    p25 = valid[f"{prediction_col}_p25"]
    p75 = valid[f"{prediction_col}_p75"]
    p90 = valid[f"{prediction_col}_p90"]
    band_mask_80 = p10.notna() & p90.notna()
    band_mask_50 = p25.notna() & p75.notna()
    coverage_80 = float(((valid.loc[band_mask_80, "actual"] >= p10[band_mask_80]) &
                         (valid.loc[band_mask_80, "actual"] <= p90[band_mask_80])).mean()) if band_mask_80.any() else None
    coverage_50 = float(((valid.loc[band_mask_50, "actual"] >= p25[band_mask_50]) &
                         (valid.loc[band_mask_50, "actual"] <= p75[band_mask_50])).mean()) if band_mask_50.any() else None
    width_80 = float((p90[band_mask_80] - p10[band_mask_80]).mean()) if band_mask_80.any() else None
    return {
        "season": season,
        "stat": stat,
        "model": model,
        **metrics,
        "median_absolute_error": float(np.median(np.abs(valid["actual"] - valid[prediction_col]))),
        "mean_actual": float(valid["actual"].mean()),
        "mean_predicted": float(valid[prediction_col].mean()),
        "coverage_50_band": coverage_50,
        "coverage_80_band": coverage_80,
        "average_80_band_width": width_80,
        "status": "PROJECTION-ONLY WALK-FORWARD TEST",
    }


def run_stat_backtest(
    games: pd.DataFrame,
    stat_columns: Iterable[str] | None = None,
    min_history: int = 3,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compare numeric stat projections with actuals; no odds or prices used.

    Returns a summary containing all-season and per-season metrics, plus a
    prediction-level detail frame suitable for CSV export and charts.
    """
    stats = list(stat_columns) if stat_columns is not None else DEFAULT_STATS
    summaries: list[dict] = []
    details: list[pd.DataFrame] = []

    for stat in stats:
        forecast = walk_forward_player_stat(games, stat, min_history=min_history)
        if forecast.empty:
            continue

        for prediction_col, model_name in MODEL_COLUMNS:
            valid = forecast[forecast[prediction_col].notna()].copy()
            if valid.empty:
                summaries.append({
                    "season": "ALL SEASONS", "stat": stat, "model": model_name,
                    "n": 0, "mae": None, "rmse": None, "bias": None,
                    "median_absolute_error": None, "mean_actual": None,
                    "mean_predicted": None, "coverage_50_band": None,
                    "coverage_80_band": None, "average_80_band_width": None,
                    "skill_vs_season_average": None,
                    "status": "NOT ENOUGH INPUT DATA",
                })
                continue

            def append_summary(subset: pd.DataFrame, season_label: int | str):
                row = _summary_row(subset, stat, model_name, prediction_col, season_label)
                model_mae = row.get("mae")
                baseline_mae = regression_metrics(
                    subset["actual"], subset["prediction_season_average"]
                )["mae"] if "prediction_season_average" in subset else None
                row["skill_vs_season_average"] = (
                    float(1.0 - model_mae / baseline_mae)
                    if baseline_mae is not None and baseline_mae > 0 and model_mae is not None
                    else (0.0 if model_name == "SEASON AVERAGE" and baseline_mae == 0 else None)
                )
                summaries.append(row)

            append_summary(valid, "ALL SEASONS")
            for season, season_rows in valid.groupby("season", sort=True):
                append_summary(season_rows, int(season))

            keep = [
                "player_id", "season", "week", "actual", "prior_games",
                "prior_season_average", "prior_last10_average", "prior_last5_average",
                "prior_last3_average", "expected_opportunities", "historical_efficiency",
                "participation_verified", prediction_col,
                f"{prediction_col}_p10", f"{prediction_col}_p25",
                f"{prediction_col}_p75", f"{prediction_col}_p90",
            ]
            part = valid[[c for c in keep if c in valid.columns]].copy()
            part["stat"] = stat
            part["model"] = model_name
            part = part.rename(columns={
                prediction_col: "predicted",
                f"{prediction_col}_p10": "prediction_p10",
                f"{prediction_col}_p25": "prediction_p25",
                f"{prediction_col}_p75": "prediction_p75",
                f"{prediction_col}_p90": "prediction_p90",
            })
            part["absolute_error"] = (part["actual"] - part["predicted"]).abs()
            part["error"] = part["predicted"] - part["actual"]
            details.append(part)

    summary_df = pd.DataFrame(summaries)
    if not summary_df.empty:
        summary_df["_season_order"] = summary_df["season"].map(
            lambda value: -1 if value == "ALL SEASONS" else int(value)
        )
        summary_df = summary_df.sort_values(
            ["stat", "_season_order", "mae"], kind="mergesort", na_position="last"
        ).drop(columns=["_season_order"]).reset_index(drop=True)
    detail_df = pd.concat(details, ignore_index=True) if details else pd.DataFrame()
    return summary_df, detail_df
