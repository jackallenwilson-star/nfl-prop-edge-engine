"""Workload x efficiency projections using current-season game logs only."""
import numpy as np

METRICS = {
    "passing_yards": ("attempts", "passing_yards"),
    "passing_tds": ("attempts", "passing_tds"),
    "completions": ("attempts", "completions"),
    "interceptions": ("attempts", "interceptions"),
    "rushing_yards": ("carries", "rushing_yards"),
    "rushing_tds": ("carries", "rushing_tds"),
    "receiving_yards": ("targets", "receiving_yards"),
    "receptions": ("targets", "receptions"),
    "receiving_tds": ("targets", "receiving_tds"),
}


def usage_projection(player_games, player_id: str, stat: str):
    if stat not in METRICS: return None, None, None
    opp, production = METRICS[stat]
    rows = player_games[player_games.player_id.astype(str) == str(player_id)].sort_values("week")
    if len(rows) < 1 or opp not in rows or production not in rows: return None, None, None
    opps = rows[opp].fillna(0).astype(float)
    eff_den = float(opps.sum())
    efficiency = float(rows[production].fillna(0).sum() / eff_den) if eff_den > 0 else None
    if efficiency is None: return None, None, None
    season_opp = float(opps.mean())
    last5_opp = float(opps.tail(5).mean())
    expected_opp = .60*last5_opp + .40*season_opp
    return float(expected_opp*efficiency), expected_opp, efficiency
