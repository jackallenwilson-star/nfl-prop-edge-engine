"""Fantasy points from projection components; scoring is configurable."""
DEFAULT_SCORING = {
    "pass_yards": .04, "pass_td": 4.0, "interception": -2.0,
    "rush_yards": .1, "rush_td": 6.0, "rec_yards": .1,
    "rec_td": 6.0, "reception": 0.0,
}


def fantasy_points(projections: dict, scoring: dict | None = None) -> float:
    s = dict(DEFAULT_SCORING)
    if scoring: s.update(scoring)
    mapping = {"passing_yards": "pass_yards", "passing_tds": "pass_td", "interceptions": "interception",
               "rushing_yards": "rush_yards", "rushing_tds": "rush_td", "receiving_yards": "rec_yards",
               "receiving_tds": "rec_td", "receptions": "reception"}
    total = 0.0
    for stat, key in mapping.items():
        value = projections.get(stat)
        if value is not None: total += float(value) * s[key]
    return total


def ppr_scoring(mode: str):
    s = dict(DEFAULT_SCORING)
    if mode.lower() == "half-ppr": s["reception"] = .5
    elif mode.lower() == "full-ppr": s["reception"] = 1.0
    return s
