"""Injury scenario helpers. No inferred injury redistribution without confirmed usage inputs."""

UNAVAILABLE = {"OUT", "INJURED RESERVE", "SUSPENDED", "DOUBTFUL"}

def redistributing_opportunities(players: list[dict], opportunity_key: str, status_key: str = "status") -> list[dict]:
    """Remove unavailable players and preserve remaining observed opportunity proportions."""
    available = [p.copy() for p in players if str(p.get(status_key, "UNKNOWN")).upper() not in UNAVAILABLE]
    total = sum(max(0.0, float(p.get(opportunity_key, 0) or 0)) for p in available)
    for p in available:
        base = max(0.0, float(p.get(opportunity_key, 0) or 0))
        p["redistributed_share"] = base / total if total > 0 else None
    return available


def injury_adjustment_supported(status: str, role_data_available: bool) -> bool:
    return status in UNAVAILABLE and role_data_available
