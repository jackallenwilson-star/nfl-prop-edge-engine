"""Market discovery wrapper and game/player scope helpers."""
from kalshi_api import KalshiClient, enrich_market
from market_parser import normalize_market
from config import KALSHI_ORDERBOOK_LIMIT


def discover_current_week_markets(client=None, orderbooks=True):
    client = client or KalshiClient()
    raw, diagnostics = client.discover_nfl_markets()
    normalized = [normalize_market(m) for m in raw]
    standard = [m for m in normalized if m.get("category") not in ("FUTURE", "OTHER")]
    limit = min(len(standard), KALSHI_ORDERBOOK_LIMIT)
    for i, market in enumerate(standard):
        if orderbooks and i < limit:
            market.update(enrich_market(market, client, use_orderbook=True))
        else:
            # Market-level price fields still provide a midpoint if both sides exist.
            market.update(enrich_market(market, client, use_orderbook=False))
    diagnostics["normalized_markets"] = len(normalized)
    diagnostics["standard_or_special_markets"] = len(standard)
    diagnostics["orderbooks_attempted"] = limit if orderbooks else 0
    return normalized, diagnostics
