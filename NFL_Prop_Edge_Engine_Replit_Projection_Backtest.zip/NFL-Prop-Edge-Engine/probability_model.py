"""Reproducible prop simulation and exact binary settlement evaluation."""
from __future__ import annotations
import numpy as np
from config import SIMULATIONS, RANDOM_SEED


def settlement_mask(samples, operator: str, threshold: float):
    x = np.asarray(samples)
    if operator == ">=": return x >= threshold
    if operator == ">": return x > threshold
    if operator == "<=": return x <= threshold
    if operator == "<": return x < threshold
    if operator == "==": return x == threshold
    raise ValueError(f"Unsupported settlement operator: {operator}")


def simulate_prop(player_values, projection: float, stat: str, operator: str, threshold: float,
                  simulations: int = SIMULATIONS, seed: int = RANDOM_SEED):
    vals = np.asarray(player_values, dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < 3 or projection is None or operator not in (">=", ">", "<=", "<", "=="):
        return {"model_yes_probability": None, "model_no_probability": None, "simulation_status": "INSUFFICIENT DATA"}
    rng = np.random.default_rng(seed)
    stat_count = stat in {"attempts", "completions", "interceptions", "carries", "receptions", "targets", "passing_tds", "rushing_tds", "receiving_tds", "sacks", "tackles"}
    if stat_count:
        mean_raw = max(0.0, float(vals.mean()))
        var_raw = max(float(vals.var(ddof=1)), mean_raw)
        scale = (var_raw / mean_raw) if mean_raw > 0 else 1.0
        mean = max(0.0, float(projection))
        if scale > 1.10 and mean > 0:
            size = max(.2, mean / max(1e-6, scale - 1))
            p = size / (size + mean)
            draws = rng.negative_binomial(size, p, size=simulations)
        else:
            draws = rng.poisson(mean, size=simulations)
    else:
        # Bootstrap observed current-season performances and shift to the candidate projection.
        centered = vals - vals.mean()
        draws = np.maximum(0, np.rint(projection + rng.choice(centered, size=simulations, replace=True))).astype(int)
    hit = settlement_mask(draws, operator, float(threshold))
    q = float(hit.mean())
    return {"model_yes_probability": q, "model_no_probability": 1-q,
            "simulation_status": "SIMULATED", "mean": float(np.mean(draws)),
            "median": float(np.median(draws)), "std": float(np.std(draws, ddof=1)),
            "p10": float(np.percentile(draws, 10)), "p25": float(np.percentile(draws, 25)),
            "p75": float(np.percentile(draws, 75)), "p90": float(np.percentile(draws, 90)),
            "simulations": int(simulations)}


def edge_calculations(market_yes: float | None, model_yes: float | None,
                      yes_ask: float | None = None, no_ask: float | None = None):
    if market_yes is None or model_yes is None:
        return {"yes_edge_pp": None, "no_edge_pp": None, "yes_ev_before_fees": None,
                "yes_roi_before_fees": None, "no_ev_before_fees": None, "no_roi_before_fees": None}
    model_no, market_no = 1-model_yes, 1-market_yes
    yes_ev = model_yes-yes_ask if yes_ask is not None else None
    no_ev = model_no-no_ask if no_ask is not None else None
    return {"yes_edge_pp": (model_yes-market_yes)*100,
            "no_edge_pp": (model_no-market_no)*100,
            "yes_ev_before_fees": yes_ev,
            "yes_roi_before_fees": yes_ev/yes_ask if yes_ev is not None and yes_ask and yes_ask > 0 else None,
            "no_ev_before_fees": no_ev,
            "no_roi_before_fees": no_ev/no_ask if no_ev is not None and no_ask and no_ask > 0 else None}
