"""Dynamic nflverse release discovery and schema-validated dataset loading."""
from __future__ import annotations
import io, json, time, re
from pathlib import Path
from typing import Iterable
import pandas as pd
import requests
from config import NFLVERSE_API, HTTP_TIMEOUT, CACHE_TTL_SECONDS, CACHE_DIR

class NFLDataError(RuntimeError):
    pass

class NFLVerseClient:
    def __init__(self, timeout: int = HTTP_TIMEOUT):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "NFL-Prop-Edge-Engine/0.1"})
        self.diagnostics: dict[str, str] = {}

    def _request_json(self, url: str):
        r = self.session.get(url, timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def get_release(self, tag: str) -> dict:
        cache_path = CACHE_DIR / f"release_{tag}.json"
        if cache_path.exists() and time.time() - cache_path.stat().st_mtime < CACHE_TTL_SECONDS:
            return json.loads(cache_path.read_text())
        url = f"{NFLVERSE_API}/releases/tags/{tag}"
        try:
            release = self._request_json(url)
        except Exception as exc:
            # Try inspecting all release metadata rather than assuming a tag exists.
            releases = self._request_json(f"{NFLVERSE_API}/releases?per_page=100")
            release = next((r for r in releases if r.get("tag_name", "").lower() == tag.lower()), None)
            if release is None:
                raise NFLDataError(f"Could not find nflverse release '{tag}': {exc}") from exc
        cache_path.write_text(json.dumps(release))
        return release

    @staticmethod
    def _asset_candidates(release: dict, required_columns: set[str], preferred_tokens: Iterable[str]) -> list[dict]:
        assets = release.get("assets", []) or []
        scored = []
        for asset in assets:
            name = str(asset.get("name", "")).lower()
            if not name.endswith((".csv", ".csv.gz", ".parquet", ".parquet.gz")):
                continue
            score = sum(4 for token in preferred_tokens if token.lower() in name)
            if name.endswith(".csv"): score += 1
            scored.append((score, asset))
        return [a for _, a in sorted(scored, key=lambda x: x[0], reverse=True)]

    def _download_frame(self, asset: dict, release_tag: str) -> pd.DataFrame:
        url = asset.get("browser_download_url")
        if not url:
            raise NFLDataError("Release asset has no download URL")
        cache_path = CACHE_DIR / f"{release_tag}_{asset.get('name', 'dataset.csv')}"
        if cache_path.exists() and time.time() - cache_path.stat().st_mtime < CACHE_TTL_SECONDS:
            payload = cache_path.read_bytes()
        else:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            payload = response.content
            cache_path.write_bytes(payload)
        name = str(asset.get("name", "")).lower()
        try:
            if name.endswith(".parquet") or name.endswith(".parquet.gz"):
                return pd.read_parquet(io.BytesIO(payload))
            compression = "gzip" if name.endswith(".csv.gz") else "infer"
            return pd.read_csv(io.BytesIO(payload), low_memory=False, compression=compression)
        except Exception as exc:
            raise NFLDataError(f"Could not parse release asset {asset.get('name')}: {exc}") from exc

    def load_release_table(self, tag: str, required_any: set[str], preferred_tokens: Iterable[str] = ()) -> pd.DataFrame:
        release = self.get_release(tag)
        candidates = self._asset_candidates(release, required_any, preferred_tokens)
        errors = []
        for asset in candidates:
            try:
                frame = self._download_frame(asset, tag)
                columns = set(map(str, frame.columns))
                if required_any.issubset(columns):
                    frame.attrs["source_release"] = release.get("tag_name", tag)
                    frame.attrs["source_asset"] = asset.get("name")
                    frame.attrs["retrieved_at"] = pd.Timestamp.utcnow().isoformat()
                    self.diagnostics[tag] = f"OK: {asset.get('name')} ({len(frame):,} rows)"
                    return frame
                errors.append(f"{asset.get('name')}: missing {sorted(required_any-columns)}")
            except Exception as exc:
                errors.append(str(exc))
        self.diagnostics[tag] = "UNAVAILABLE: " + "; ".join(errors[:3])
        raise NFLDataError(f"No asset in release '{tag}' matched columns {sorted(required_any)}. {self.diagnostics[tag]}")

    def load_schedules(self) -> pd.DataFrame:
        return self.load_release_table("schedules", {"season", "week", "home_team", "away_team"}, ("games", "schedule"))

    @staticmethod
    def _validate_player_stats(frame: pd.DataFrame, asset_name: str) -> pd.DataFrame:
        required = {"season", "week"}
        if not ({"player_id", "gsis_id"} & set(frame.columns)):
            raise NFLDataError(f"{asset_name}: player ID column missing")
        stat_columns = {"passing_yards", "passing_tds", "passing_interceptions", "rushing_yards",
                        "rushing_tds", "receiving_yards", "receiving_tds", "targets", "carries", "receptions"}
        if not (stat_columns & set(frame.columns)):
            raise NFLDataError(f"{asset_name}: recognizable player game-stat columns missing")
        if not required.issubset(frame.columns):
            raise NFLDataError(f"{asset_name}: required columns missing: {sorted(required-set(frame.columns))}")
        frame = frame.copy()
        frame.attrs["source_asset"] = asset_name
        return frame

    def _player_stats_assets(self) -> tuple[dict, dict[int, dict]]:
        release = self.get_release("stats_player")
        by_season: dict[int, dict] = {}
        pattern = re.compile(r"^stats_player_week_(\d{4})\.(?:csv|csv\.gz|parquet|parquet\.gz)$", re.I)
        for asset in release.get("assets", []) or []:
            name = str(asset.get("name", ""))
            match = pattern.match(name)
            if match:
                by_season[int(match.group(1))] = asset
        if not by_season:
            raise NFLDataError("The stats_player release did not expose season-specific weekly player-stat assets")
        return release, by_season

    def load_player_stats(self, seasons: int | Iterable[int] | None = None) -> pd.DataFrame:
        """Load weekly player stats for explicit season(s); default is latest listed season.

        nflverse's documented release convention is stats_player_week_{season}.{csv|parquet}.
        Each selected asset is discovered from release metadata and schema-validated.
        """
        release, assets = self._player_stats_assets()
        if seasons is None:
            selected = [max(assets)]
        elif isinstance(seasons, int):
            selected = [int(seasons)]
        else:
            selected = sorted({int(year) for year in seasons})
        frames, errors = [], []
        for year in selected:
            asset = assets.get(year)
            if asset is None:
                errors.append(f"{year}: no weekly stats asset in release")
                continue
            try:
                frame = self._download_frame(asset, "stats_player")
                frame = self._validate_player_stats(frame, str(asset.get("name")))
                frame = frame[pd.to_numeric(frame.season, errors="coerce").eq(year)].copy()
                frame.attrs["source_release"] = release.get("tag_name", "stats_player")
                frame.attrs["retrieved_at"] = pd.Timestamp.utcnow().isoformat()
                frames.append(frame)
                self.diagnostics[f"stats_{year}"] = f"OK: {asset.get('name')} ({len(frame):,} rows)"
            except Exception as exc:
                errors.append(f"{year}: {exc}")
                self.diagnostics[f"stats_{year}"] = f"UNAVAILABLE: {exc}"
        if not frames:
            self.diagnostics["stats"] = "UNAVAILABLE: " + "; ".join(errors[:5])
            raise NFLDataError(self.diagnostics["stats"])
        out = pd.concat(frames, ignore_index=True, sort=False)
        out.attrs["seasons_loaded"] = sorted(pd.to_numeric(out.season, errors="coerce").dropna().astype(int).unique().tolist())
        out.attrs["source_release"] = release.get("tag_name", "stats_player")
        self.diagnostics["stats"] = f"OK: {len(frames)} season asset(s), {len(out):,} rows"
        if errors:
            self.diagnostics["stats_partial_errors"] = "; ".join(errors[:8])
        return out

    def load_historical_player_stats(self, start_year: int, end_year: int) -> pd.DataFrame:
        """Load available season assets for a separate historical/backtest panel."""
        years = range(int(start_year), int(end_year) + 1)
        return self.load_player_stats(years)

    def load_weekly_rosters(self) -> pd.DataFrame:
        frame = self.load_release_table("weekly_rosters", {"season", "week"}, ("weekly_roster", "roster"))
        if not any(c in frame.columns for c in ("gsis_id", "player_id")):
            raise NFLDataError("Weekly roster asset has no recognized player identifier")
        return frame

    def load_players(self) -> pd.DataFrame:
        return self.load_release_table("players", {"gsis_id"}, ("players",))

    def load_snap_counts(self) -> pd.DataFrame:
        return self.load_release_table("snap_counts", {"season", "week"}, ("snap",))

    def load_injuries(self, season: int) -> pd.DataFrame:
        """Load only the exact season partition from nflverse's injuries release."""
        try:
            release = self.get_release("injuries")
            candidates = self._asset_candidates(release, {"season"}, (f"injuries_{int(season)}",))
            if not candidates:
                raise NFLDataError(f"No injury asset for season {season} was listed in the release")
            errors = []
            for asset in candidates:
                if f"injuries_{int(season)}" not in str(asset.get("name", "")).lower():
                    continue
                frame = self._download_frame(asset, "injuries")
                required_id = any(c in frame.columns for c in ("gsis_id", "player_id"))
                required_status = any(c in frame.columns for c in ("report_status", "injury_status", "status"))
                if not required_id or not required_status:
                    errors.append(f"{asset.get('name')}: player ID or status column missing")
                    continue
                frame.attrs["source_release"] = release.get("tag_name", "injuries")
                frame.attrs["source_asset"] = asset.get("name")
                frame.attrs["retrieved_at"] = pd.Timestamp.utcnow().isoformat()
                self.diagnostics["injuries"] = f"OK: {asset.get('name')} ({len(frame):,} rows)"
                return frame
            raise NFLDataError("No season-specific injury asset passed schema validation. " + "; ".join(errors))
        except Exception as exc:
            self.diagnostics["injuries"] = f"UNAVAILABLE: {exc}"
            raise


def load_core_data() -> dict:
    client = NFLVerseClient()
    data, errors = {}, {}
    # Load schedule first so the live stats request is explicitly tied to the current week.
    loaders = {"schedule": client.load_schedules, "rosters": client.load_weekly_rosters,
               "players": client.load_players, "snaps": client.load_snap_counts}
    for name, loader in loaders.items():
        try:
            data[name] = loader()
        except Exception as exc:
            errors[name] = str(exc)

    if "schedule" in data:
        try:
            from schedule import normalize_schedule, current_season_week
            schedule_frame = normalize_schedule(data["schedule"])
            live_season, _, _ = current_season_week(schedule_frame)
            if live_season is None:
                import datetime
                years = pd.to_numeric(data["schedule"].get("season", pd.Series(dtype=float)), errors="coerce").dropna()
                calendar_year = datetime.datetime.now(datetime.timezone.utc).year
                prior = years[years <= calendar_year]
                live_season = int(prior.max()) if not prior.empty else calendar_year
            data["live_season"] = int(live_season)
            data["stats"] = client.load_player_stats(int(live_season))
        except Exception as exc:
            errors["stats"] = str(exc)
        try:
            if "live_season" not in data:
                raise NFLDataError("Cannot identify a season for injury data")
            data["injuries"] = client.load_injuries(int(data["live_season"]))
        except Exception as exc:
            errors["injuries"] = str(exc)
    else:
        errors["stats"] = "Not attempted because schedule could not identify the live season"
        errors["injuries"] = "Not attempted because schedule could not identify the current season"
    return {"data": data, "errors": errors, "diagnostics": client.diagnostics}
