"""Game-script layer. Returns unavailable/neutral until supported game-level Kalshi inputs exist."""

def game_script_factor(home_team: str, away_team: str, game_market_rows: list[dict] | None = None):
    rows = game_market_rows or []
    usable = [r for r in rows if r.get("market_yes_probability") is not None and r.get("market_kind") == "STANDARD CANDIDATE"]
    if not usable:
        return {"factor": 1.0, "status": "NEUTRAL — no verified game-level Kalshi input", "data_available": False}
    return {"factor": 1.0, "status": "NEUTRAL — game market parser not yet validated", "data_available": False}
