"""Conservative roster/injury status handling."""
import pandas as pd

UNAVAILABLE_TERMS = {"OUT", "IR", "INJURED RESERVE", "PUP", "SUSPENDED", "INACTIVE"}
DOUBTFUL_TERMS = {"DOUBTFUL"}
QUESTIONABLE_TERMS = {"QUESTIONABLE", "Q", "LIMITED", "DID NOT PARTICIPATE", "DNP"}


def status_for_player(player_id: str, team: str, roster_df: pd.DataFrame | None,
                      injury_df: pd.DataFrame | None) -> tuple[str, str]:
    rostered = False
    if roster_df is not None and not roster_df.empty:
        id_col = next((c for c in ("gsis_id", "player_id") if c in roster_df.columns), None)
        team_col = next((c for c in ("team", "recent_team", "team_abbr") if c in roster_df.columns), None)
        if id_col:
            rows = roster_df[roster_df[id_col].astype(str) == str(player_id)]
            if team_col and team:
                rows = rows[rows[team_col].astype(str).str.upper() == str(team).upper()]
            rostered = not rows.empty
    injury_status = "UNKNOWN"
    source = "No injury feed verified"
    if injury_df is not None and not injury_df.empty:
        id_col = next((c for c in ("gsis_id", "player_id") if c in injury_df.columns), None)
        status_col = next((c for c in ("report_status", "injury_status", "status", "practice_status") if c in injury_df.columns), None)
        if id_col and status_col:
            rows = injury_df[injury_df[id_col].astype(str) == str(player_id)]
            if not rows.empty:
                raw = str(rows.iloc[-1][status_col]).upper()
                source = f"Injury feed: {raw}"
                if any(t in raw for t in UNAVAILABLE_TERMS): injury_status = "OUT"
                elif any(t in raw for t in DOUBTFUL_TERMS): injury_status = "DOUBTFUL"
                elif any(t in raw for t in QUESTIONABLE_TERMS): injury_status = "QUESTIONABLE"
                elif raw.strip() in {"ACTIVE", "NO DESIGNATION"}: injury_status = "ACTIVE"
    if injury_status in {"OUT", "DOUBTFUL", "QUESTIONABLE", "ACTIVE"}:
        return injury_status, source
    if rostered and not roster_df.empty:
        id_col = next((c for c in ("gsis_id", "player_id") if c in roster_df.columns), None)
        status_col = next((c for c in ("status", "roster_status", "game_status") if c in roster_df.columns), None)
        if id_col and status_col:
            rows = roster_df[roster_df[id_col].astype(str) == str(player_id)]
            if not rows.empty and str(rows.iloc[-1][status_col]).upper() in {"ACT", "ACTIVE"}:
                return "ACTIVE", "Current-week roster explicitly marks player ACT/ACTIVE"
        return "UNKNOWN", "On weekly roster; injury status not explicitly ACTIVE"
    return "UNKNOWN", "Current weekly roster not confirmed"


def actionable_status(status: str) -> bool:
    return status == "ACTIVE"
