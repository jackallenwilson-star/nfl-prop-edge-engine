"""Build a conservative standard binary player-prop prediction."""
import numpy as np
from features import summarize_player
from historical_model import weighted_recent, shrink_projection
from usage_model import usage_projection
from probability_model import simulate_prop, edge_calculations
from ensemble_model import ensemble_projection
from config import MIN_GAMES_FOR_MODEL, SIMULATIONS, RANDOM_SEED


def predict_market(market: dict, matched_player: dict, player_games, status: str,
                   simulations: int = SIMULATIONS) -> dict:
    out = dict(market)
    if not matched_player or not market.get("stat_key") or market.get("parse_status") != "PARSED":
        out.update({"model_projection": None, "model_yes_probability": None,
                    "prediction_status": "UNAVAILABLE — player/stat/contract not verified"})
        out.update(edge_calculations(out.get("market_yes_probability"), None))
        return out
    pid, stat = matched_player["player_id"], market["stat_key"]
    summary = summarize_player(player_games, pid, stat, market.get("threshold"), market.get("operator"))
    rows = player_games[player_games.player_id.astype(str) == str(pid)].sort_values("week")
    if stat not in rows or len(rows) < MIN_GAMES_FOR_MODEL:
        out.update({"player": matched_player["player_name"], "player_id": pid, **summary,
                    "model_projection": None, "model_yes_probability": None,
                    "prediction_status": "INSUFFICIENT DATA"})
        out.update(edge_calculations(out.get("market_yes_probability"), None))
        return out
    raw_a = weighted_recent(summary, "A")
    raw_b = weighted_recent(summary, "B")
    # Positional prior only from this season's current dataset.
    position_col = "position" if "position" in rows.columns else None
    positional = None
    all_stat = player_games[stat].dropna()
    if position_col and "position" in player_games:
        positions = player_games[player_games.player_id.astype(str) == str(pid)]["position"].dropna()
        if not positions.empty:
            positional_rows = player_games[player_games.position.astype(str) == str(positions.iloc[-1])]
            if not positional_rows.empty: positional = float(positional_rows[stat].mean())
    if positional is None and not all_stat.empty: positional = float(all_stat.mean())
    m1 = shrink_projection(raw_a, summary["games"], positional)
    usage, opportunities, efficiency = usage_projection(player_games, pid, stat)
    # Keep Model 3/4/5 neutral and out of ensemble until their game-specific inputs pass validation.
    ensemble = ensemble_projection(m1, usage)
    samples = pd_numeric_values(rows, stat)
    sim = simulate_prop(samples, ensemble, stat, market["operator"], market["threshold"], simulations, RANDOM_SEED)
    out.update({"player": matched_player["player_name"], "player_id": pid,
                "team": matched_player.get("team"), "position": matched_player.get("position"), **summary,
                "model1a_projection": raw_a, "model1b_projection": raw_b,
                "model2_usage_projection": usage, "expected_opportunities": opportunities,
                "expected_efficiency": efficiency, "model3_matchup": "UNAVAILABLE — no validated opponent table",
                "model4_injury": "NEUTRAL — redistribution inputs not validated",
                "model5_game_script": "NEUTRAL — verified game-market inputs unavailable",
                "model_projection": ensemble, **sim,
                "injury_status": status,
                "prediction_status": "MODEL OUTPUT — NOT YET BACKTEST-VALIDATED" if sim.get("model_yes_probability") is not None else sim.get("simulation_status", "UNAVAILABLE")})
    out.update(edge_calculations(out.get("market_yes_probability"), out.get("model_yes_probability"),
                                 out.get("yes_ask"), out.get("no_ask")))
    # No actionable label unless roster/injury status is explicitly ACTIVE.
    yes_edge = out.get("yes_edge_pp")
    no_edge = out.get("no_edge_pp")
    if yes_edge is None or no_edge is None:
        out.update({"positive_edge_side": None, "best_edge_pp": None,
                    "best_ev_before_fees": None, "best_roi_before_fees": None})
    elif yes_edge > 0:
        out.update({"positive_edge_side": "YES", "best_edge_pp": yes_edge,
                    "best_ev_before_fees": out.get("yes_ev_before_fees"),
                    "best_roi_before_fees": out.get("yes_roi_before_fees")})
    elif no_edge > 0:
        out.update({"positive_edge_side": "NO", "best_edge_pp": no_edge,
                    "best_ev_before_fees": out.get("no_ev_before_fees"),
                    "best_roi_before_fees": out.get("no_roi_before_fees")})
    else:
        out.update({"positive_edge_side": None, "best_edge_pp": 0.0,
                    "best_ev_before_fees": None, "best_roi_before_fees": None})

    if status != "ACTIVE": out["recommendation_status"] = "HIGH RISK / NOT ACTIONABLE — status not verified ACTIVE"
    elif out.get("model_yes_probability") is None: out["recommendation_status"] = "INSUFFICIENT DATA"
    elif yes_edge is None: out["recommendation_status"] = "PRICE UNAVAILABLE"
    elif abs(yes_edge) < 1: out["recommendation_status"] = "NO CLEAR MODEL EDGE"
    elif yes_edge > 0: out["recommendation_status"] = "POSITIVE MODEL EDGE ON YES — UNVALIDATED MODEL"
    else: out["recommendation_status"] = "POSITIVE MODEL EDGE ON NO — UNVALIDATED MODEL"
    return out


def pd_numeric_values(rows, stat):
    import pandas as pd
    return pd.to_numeric(rows[stat], errors="coerce").dropna().to_numpy(dtype=float)
