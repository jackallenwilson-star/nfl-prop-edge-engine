"""Read-only Kalshi Trade API client. No order placement code exists here."""
from __future__ import annotations
import time
import requests
from typing import Any
from config import KALSHI_BASE_URL, KALSHI_TIMEOUT, KALSHI_MAX_PAGES

class KalshiAPIError(RuntimeError):
    pass

class KalshiClient:
    def __init__(self, base_url: str = KALSHI_BASE_URL, timeout: int = KALSHI_TIMEOUT):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "NFL-Prop-Edge-Engine/0.1 read-only"})

    def get(self, path: str, params: dict | None = None) -> dict:
        url = f"{self.base_url}/{path.lstrip('/')}"
        try:
            response = self.session.get(url, params=params or {}, timeout=self.timeout)
            if response.status_code >= 400:
                raise KalshiAPIError(f"Kalshi HTTP {response.status_code}: {response.text[:300]}")
            payload = response.json()
            if not isinstance(payload, dict):
                raise KalshiAPIError("Kalshi returned a non-object JSON response")
            return payload
        except requests.RequestException as exc:
            raise KalshiAPIError(f"Kalshi request failed: {exc}") from exc

    def paginate(self, path: str, key: str, params: dict | None = None,
                 max_pages: int = KALSHI_MAX_PAGES, limit: int = 200) -> list[dict]:
        rows, cursor = [], None
        for _ in range(max_pages):
            query = dict(params or {})
            query["limit"] = limit
            if cursor:
                query["cursor"] = cursor
            result = self.get(path, query)
            batch = result.get(key, []) or []
            if not isinstance(batch, list):
                break
            rows.extend(x for x in batch if isinstance(x, dict))
            cursor = result.get("cursor") or result.get("next_cursor")
            if not cursor or not batch:
                break
        return rows

    def list_series(self) -> list[dict]:
        # The endpoint is public. Some API versions expose only a limited set per page.
        return self.paginate("series", "series", max_pages=KALSHI_MAX_PAGES, limit=200)

    def list_events(self, series_ticker: str | None = None, status: str = "open") -> list[dict]:
        params = {"status": status, "with_nested_markets": "true"}
        if series_ticker:
            params["series_ticker"] = series_ticker
        return self.paginate("events", "events", params=params, max_pages=KALSHI_MAX_PAGES, limit=200)

    def list_markets(self, event_ticker: str | None = None, series_ticker: str | None = None,
                     status: str = "open") -> list[dict]:
        params = {"status": status}
        if event_ticker:
            params["event_ticker"] = event_ticker
        if series_ticker:
            params["series_ticker"] = series_ticker
        return self.paginate("markets", "markets", params=params, max_pages=KALSHI_MAX_PAGES, limit=500)

    def get_orderbook(self, ticker: str) -> dict:
        # Kalshi has changed access requirements on some order-book routes; callers handle failure.
        return self.get(f"markets/{ticker}/orderbook")

    def discover_nfl_markets(self) -> tuple[list[dict], dict]:
        """Discover relevant open markets by inspecting series metadata, then events.

        We intentionally do not guess a single NFL series ticker. If series discovery is
        incomplete, a capped event scan is used as a fallback.
        """
        diagnostics = {"series_seen": 0, "nfl_series": 0, "events_seen": 0,
                      "markets_seen": 0, "errors": []}
        markets_by_ticker: dict[str, dict] = {}
        try:
            series = self.list_series()
            diagnostics["series_seen"] = len(series)
            selected = []
            for item in series:
                label = " ".join(str(item.get(k, "")) for k in ("ticker", "title", "name", "category", "tags", "description")).lower()
                if any(term in label for term in ("nfl", "national football", "football")):
                    selected.append(item)
            diagnostics["nfl_series"] = len(selected)
            if not selected:
                # Fallback for Kalshi catalog versions whose series metadata omits sport tags.
                for status in ("open", "unopened"):
                    try:
                        broad_events = self.list_events(None, status)
                        diagnostics["events_seen"] += len(broad_events)
                        for event in broad_events:
                            event_label = " ".join(str(event.get(k, "")) for k in ("title", "sub_title", "ticker", "category")).lower()
                            if "nfl" not in event_label and "football" not in event_label:
                                continue
                            nested = event.get("markets") or []
                            for market in nested:
                                if isinstance(market, dict):
                                    row = dict(market)
                                    row.setdefault("event_ticker", event.get("event_ticker") or event.get("ticker"))
                                    row.setdefault("event_title", event.get("title") or event.get("sub_title") or "")
                                    row.setdefault("series_ticker", event.get("series_ticker"))
                                    markets_by_ticker[row.get("ticker", repr(row))] = row
                    except Exception as exc:
                        diagnostics["errors"].append(f"Broad event fallback ({status}): {exc}")
            for s in selected:
                ticker = s.get("ticker")
                if not ticker:
                    continue
                for status in ("open", "unopened"):
                    try:
                        events = self.list_events(str(ticker), status)
                        diagnostics["events_seen"] += len(events)
                        for event in events:
                            event_title = event.get("title") or event.get("sub_title") or event.get("ticker") or ""
                            nested = event.get("markets") or []
                            for market in nested:
                                if isinstance(market, dict):
                                    row = dict(market)
                                    row.setdefault("event_ticker", event.get("event_ticker") or event.get("ticker"))
                                    row.setdefault("event_title", event_title)
                                    row.setdefault("series_ticker", ticker)
                                    markets_by_ticker[row.get("ticker", repr(row))] = row
                    except Exception as exc:
                        diagnostics["errors"].append(f"Series {ticker} events ({status}): {exc}")
            # Some releases/series do not return nested markets. Query markets per discovered series.
            for s in selected:
                ticker = s.get("ticker")
                if not ticker:
                    continue
                try:
                    for status in ("open", "unopened"):
                        for market in self.list_markets(series_ticker=str(ticker), status=status):
                            market.setdefault("series_ticker", ticker)
                            markets_by_ticker[market.get("ticker", repr(market))] = market
                except Exception as exc:
                    diagnostics["errors"].append(f"Markets {ticker}: {exc}")
        except Exception as exc:
            diagnostics["errors"].append(f"Series discovery: {exc}")

        # Text validation is deliberately loose here; strict game/player matching happens later.
        filtered = []
        for market in markets_by_ticker.values():
            label = " ".join(str(market.get(k, "")) for k in ("title", "subtitle", "yes_sub_title", "rules_primary", "event_title", "series_ticker")).lower()
            if any(t in label for t in ("nfl", "football", "passing yards", "rushing yards", "receiving yards", "touchdown", "receptions", "sacks")):
                filtered.append(market)
        diagnostics["markets_seen"] = len(filtered)
        return filtered, diagnostics


def _dollar_value(market: dict, dollar_key: str, legacy_key: str) -> float | None:
    value = market.get(dollar_key)
    if value is not None:
        try: return float(value)
        except (TypeError, ValueError): return None
    value = market.get(legacy_key)
    if value is None: return None
    try: return float(value) / 100.0
    except (TypeError, ValueError): return None


def normalize_market_prices(market: dict, orderbook: dict | None = None) -> dict:
    """Normalize quote data to dollar probabilities [0,1]. Never fabricate missing quotes."""
    yb = _dollar_value(market, "yes_bid_dollars", "yes_bid")
    ya = _dollar_value(market, "yes_ask_dollars", "yes_ask")
    nb = _dollar_value(market, "no_bid_dollars", "no_bid")
    na = _dollar_value(market, "no_ask_dollars", "no_ask")
    source = "MARKET QUOTE"
    ob = (orderbook or {}).get("orderbook_fp") or (orderbook or {}).get("orderbook") or {}
    if ob:
        yes_levels = ob.get("yes_dollars") or ob.get("yes") or []
        no_levels = ob.get("no_dollars") or ob.get("no") or []
        def best(levels):
            vals=[]
            for level in levels or []:
                try:
                    raw_price = level.get("price_dollars", level.get("price")) if isinstance(level, dict) else level[0]
                    p=float(raw_price)
                    if p > 1: p /= 100.0
                    vals.append(p)
                except (TypeError, ValueError, IndexError, KeyError): pass
            return max(vals) if vals else None
        ob_yb, ob_nb = best(yes_levels), best(no_levels)
        if ob_yb is not None: yb = ob_yb
        if ob_nb is not None: nb = ob_nb
        if ob_yb is not None or ob_nb is not None:
            source = "ORDER BOOK"
        if nb is not None and ya is None: ya = 1.0 - nb
        if yb is not None and na is None: na = 1.0 - yb
    if ya is None and nb is not None: ya = 1.0 - nb
    if na is None and yb is not None: na = 1.0 - yb
    last = _dollar_value(market, "last_price_dollars", "last_price")
    if last is not None and not (0 <= last <= 1): last = None
    valid = lambda x: x is not None and 0 <= x <= 1
    yb = yb if valid(yb) else None
    ya = ya if valid(ya) else None
    nb = nb if valid(nb) else None
    na = na if valid(na) else None
    midpoint = (yb + ya) / 2 if yb is not None and ya is not None and yb <= ya else None
    spread = ya - yb if midpoint is not None else None
    quote = "MIDPOINT" if midpoint is not None else "UNAVAILABLE"
    if midpoint is None and last is not None:
        # A last trade is not treated as a quote or midpoint; it cannot support the edge.
        quote = "LAST TRADE ONLY"
    return {"yes_bid": yb, "yes_ask": ya, "no_bid": nb, "no_ask": na,
            "last_trade": last, "market_yes_probability": midpoint,
            "market_no_probability": 1-midpoint if midpoint is not None else None,
            "spread": spread, "quote_source": source, "quote_label": quote}


def enrich_market(market: dict, client: KalshiClient, use_orderbook: bool = True) -> dict:
    row = dict(market)
    ob = None
    if use_orderbook:
        try: ob = client.get_orderbook(str(row.get("ticker", "")))
        except Exception as exc: row["orderbook_error"] = str(exc)
    row.update(normalize_market_prices(row, ob))
    # Timestamps are kept raw; app layer computes freshness.
    return row
