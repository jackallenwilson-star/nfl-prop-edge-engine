"""Metrics for out-of-sample player-stat projections and probabilities."""
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, brier_score_loss, log_loss


def regression_metrics(actual, predicted):
    a, p = np.asarray(actual, dtype=float), np.asarray(predicted, dtype=float)
    mask = np.isfinite(a) & np.isfinite(p)
    a, p = a[mask], p[mask]
    if not len(a):
        return {"n": 0, "mae": None, "rmse": None, "bias": None}
    errors = p - a
    return {
        "n": int(len(a)),
        "mae": float(mean_absolute_error(a, p)),
        "rmse": float(mean_squared_error(a, p) ** 0.5),
        "bias": float(np.mean(errors)),
    }


def probability_metrics(actual_binary, predicted_probability):
    """Optional utility for future line-based projection validation.

    Not used by the current projection-only backtest because no historical
    contract lines or historical market probabilities are assumed.
    """
    a, p = np.asarray(actual_binary, dtype=int), np.asarray(predicted_probability, dtype=float)
    mask = np.isfinite(p)
    a, p = a[mask], np.clip(p[mask], 1e-6, 1 - 1e-6)
    if not len(a):
        return {"n": 0, "brier": None, "log_loss": None}
    return {"n": int(len(a)), "brier": float(brier_score_loss(a, p)),
            "log_loss": float(log_loss(a, p, labels=[0, 1]))}
