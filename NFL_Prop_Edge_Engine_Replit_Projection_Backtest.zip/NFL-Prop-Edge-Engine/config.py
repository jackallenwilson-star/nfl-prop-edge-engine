"""Configuration for NFL Prop Edge Engine."""
from pathlib import Path
import os

APP_NAME = "NFL PROP EDGE ENGINE"
ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
CACHE_DIR = DATA_DIR / "cache"
HISTORICAL_DIR = DATA_DIR / "historical"
PREDICTIONS_DIR = DATA_DIR / "predictions"
MODEL_DIR = ROOT / "models" / "saved_models"
DB_PATH = DATA_DIR / "nfl_prop_edge.sqlite"

for path in (CACHE_DIR, HISTORICAL_DIR, PREDICTIONS_DIR, MODEL_DIR):
    path.mkdir(parents=True, exist_ok=True)

KALSHI_BASE_URL = os.getenv(
    "KALSHI_BASE_URL", "https://external-api.kalshi.com/trade-api/v2"
).rstrip("/")
KALSHI_TIMEOUT = int(os.getenv("KALSHI_TIMEOUT", "18"))
KALSHI_MAX_PAGES = int(os.getenv("KALSHI_MAX_PAGES", "12"))
KALSHI_ORDERBOOK_LIMIT = int(os.getenv("KALSHI_ORDERBOOK_LIMIT", "60"))
NFLVERSE_REPO = "nflverse/nflverse-data"
NFLVERSE_API = f"https://api.github.com/repos/{NFLVERSE_REPO}"
HTTP_TIMEOUT = int(os.getenv("HTTP_TIMEOUT", "30"))
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "900"))
STALE_QUOTE_SECONDS = int(os.getenv("STALE_QUOTE_SECONDS", "1800"))
MIN_GAMES_FOR_MODEL = int(os.getenv("MIN_GAMES_FOR_MODEL", "3"))
SIMULATIONS = int(os.getenv("SIMULATIONS", "10000"))
RANDOM_SEED = int(os.getenv("RANDOM_SEED", "20261104"))
LOCAL_TIMEZONE = os.getenv("LOCAL_TIMEZONE", "America/Los_Angeles")
NFL_SEASON_TYPE = "REG"
BACKTEST_START_SEASON = int(os.getenv("BACKTEST_START_SEASON", "2018"))
MODEL_VERSION = "0.1.0-foundation"

TEAM_ALIASES = {
    "ARI": ["arizona", "cardinals", "ari"], "ATL": ["atlanta", "falcons", "atl"],
    "BAL": ["baltimore", "ravens", "bal"], "BUF": ["buffalo", "bills", "buf"],
    "CAR": ["carolina", "panthers", "car"], "CHI": ["chicago", "bears", "chi"],
    "CIN": ["cincinnati", "bengals", "cin"], "CLE": ["cleveland", "browns", "cle"],
    "DAL": ["dallas", "cowboys", "dal"], "DEN": ["denver", "broncos", "den"],
    "DET": ["detroit", "lions", "det"], "GB": ["green bay", "packers", "gb", "gnb"],
    "HOU": ["houston", "texans", "hou"], "IND": ["indianapolis", "colts", "ind"],
    "JAX": ["jacksonville", "jaguars", "jax", "jac"], "KC": ["kansas city", "chiefs", "kc", "kan"],
    "LAC": ["los angeles chargers", "chargers", "lac"], "LAR": ["los angeles rams", "rams", "lar"],
    "LV": ["las vegas", "raiders", "lv", "rai"], "MIA": ["miami", "dolphins", "mia"],
    "MIN": ["minnesota", "vikings", "min"], "NE": ["new england", "patriots", "ne", "nwe"],
    "NO": ["new orleans", "saints", "no", "nor"], "NYG": ["new york giants", "giants", "nyg"],
    "NYJ": ["new york jets", "jets", "nyj"], "PHI": ["philadelphia", "eagles", "phi"],
    "PIT": ["pittsburgh", "steelers", "pit"], "SF": ["san francisco", "49ers", "sf", "sfo"],
    "SEA": ["seattle", "seahawks", "sea"], "TB": ["tampa bay", "buccaneers", "tb", "tam"],
    "TEN": ["tennessee", "titans", "ten"], "WAS": ["washington", "commanders", "was", "wsh"],
}
