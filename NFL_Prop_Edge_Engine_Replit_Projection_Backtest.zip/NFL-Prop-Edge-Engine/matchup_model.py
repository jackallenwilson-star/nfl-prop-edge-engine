"""Conservative opponent adjustment. Neutral unless supported current-season inputs exist."""

def matchup_adjustment(opponent_allowed: float | None, league_average: float | None,
                       games_sampled: int, beta: float = .25) -> float | None:
    if opponent_allowed is None or league_average is None or league_average <= 0 or games_sampled < 4:
        return None
    ratio = opponent_allowed / league_average
    raw = 1 + beta * (ratio - 1)
    # Shrink small opponent samples toward neutral, even after minimum sample threshold.
    reliability = games_sampled / (games_sampled + 5)
    adjusted = 1 + reliability * (raw - 1)
    return max(.85, min(1.15, adjusted))
