"""Validated-input-only ensemble; does not silently treat missing models as zero."""

def ensemble_projection(model1: float | None, model2: float | None, weights=(.60, .40)):
    valid = [(model1, weights[0]), (model2, weights[1])]
    valid = [(v,w) for v,w in valid if v is not None]
    if not valid: return None
    denom = sum(w for _,w in valid)
    return float(sum(v*w for v,w in valid)/denom) if denom else None
