"""NFL schedule normalization and current official week selection."""
from __future__ import annotations
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import pandas as pd
from config import LOCAL_TIMEZONE


def _first(row, names, default=None):
    for name in names:
        if name in row and pd.notna(row[name]): return row[name]
    return default


def normalize_schedule(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty: return pd.DataFrame()
    x = df.copy()
    if "game_id" not in x: x["game_id"] = x.index.astype(str)
    if "game_type" in x: x = x[x["game_type"].astype(str).str.upper().eq("REG")].copy()
    x["season"] = pd.to_numeric(x["season"], errors="coerce")
    x["week"] = pd.to_numeric(x["week"], errors="coerce")
    if "gameday" in x:
        dates = pd.to_datetime(x["gameday"], errors="coerce")
    elif "game_date" in x:
        dates = pd.to_datetime(x["game_date"], errors="coerce")
    else:
        dates = pd.Series(pd.NaT, index=x.index)
    times = x["gametime"] if "gametime" in x else pd.Series("13:00", index=x.index)
    kickoff_utc = []
    for idx, d in dates.items():
        if pd.isna(d): kickoff_utc.append(pd.NaT); continue
        t = str(times.loc[idx]) if idx in times.index else "13:00"
        try:
            # nflverse schedules express kickoff as Eastern Time. Explicitly document this assumption.
            tm = pd.to_datetime(t, format="%H:%M", errors="coerce")
            if pd.isna(tm): tm = pd.Timestamp("13:00")
            local = datetime(d.year, d.month, d.day, tm.hour, tm.minute, tzinfo=ZoneInfo("America/New_York"))
            kickoff_utc.append(pd.Timestamp(local.astimezone(timezone.utc)))
        except Exception: kickoff_utc.append(pd.NaT)
    x["kickoff_utc"] = kickoff_utc
    x = x.dropna(subset=["season", "week", "home_team", "away_team", "kickoff_utc"]).copy()
    x["season"] = x["season"].astype(int); x["week"] = x["week"].astype(int)
    x["kickoff_local"] = x["kickoff_utc"].dt.tz_convert(LOCAL_TIMEZONE)
    return x.sort_values("kickoff_utc").reset_index(drop=True)


def current_season_week(schedule: pd.DataFrame, now=None) -> tuple[int | None, int | None, pd.DataFrame]:
    """Return the season/week containing the next unstarted regular-season game(s)."""
    if schedule is None or schedule.empty: return None, None, pd.DataFrame()
    now = pd.Timestamp(now or datetime.now(timezone.utc))
    if now.tzinfo is None: now = now.tz_localize("UTC")
    else: now = now.tz_convert("UTC")
    future = schedule[schedule["kickoff_utc"] >= now - pd.Timedelta(hours=4)]
    if future.empty:
        return None, None, pd.DataFrame()
    first = future.sort_values("kickoff_utc").iloc[0]
    # Long gaps before the next regular-season game indicate the NFL offseason.
    if (first.kickoff_utc - now) > pd.Timedelta(days=45):
        return None, None, pd.DataFrame()
    season, week = int(first.season), int(first.week)
    games = schedule[(schedule.season == season) & (schedule.week == week)].copy()
    games["status"] = games["kickoff_utc"].apply(
        lambda k: "UPCOMING" if k > now else ("LIVE" if now - k < pd.Timedelta(hours=4) else "FINAL")
    )
    return season, week, games.sort_values("kickoff_utc").reset_index(drop=True)
