import pandas as pd
from schedule import normalize_schedule, current_season_week


def test_current_week_uses_next_official_week():
    raw = pd.DataFrame([
        {"game_id":"a","season":2026,"week":8,"game_type":"REG","gameday":"2026-10-25","gametime":"13:00","home_team":"SEA","away_team":"SF"},
        {"game_id":"b","season":2026,"week":9,"game_type":"REG","gameday":"2026-11-05","gametime":"20:15","home_team":"NE","away_team":"NYJ"},
    ])
    sched = normalize_schedule(raw)
    season, week, games = current_season_week(sched, pd.Timestamp("2026-11-04T20:00:00Z"))
    assert season == 2026 and week == 9
    assert len(games) == 1
