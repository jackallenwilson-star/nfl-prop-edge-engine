from historical_model import weighted_recent, shrink_projection
from usage_model import usage_projection
import pandas as pd


def test_recent_formula_and_shrinkage():
    s={"average":50,"last10":40,"last5":30,"last3":20}
    assert weighted_recent(s,"A") == 39.0
    assert weighted_recent(s,"B") == 35.5
    assert abs(shrink_projection(60,5,40)-50) < 1e-9


def test_usage_projection():
    rows=pd.DataFrame([{"player_id":"p","week":1,"attempts":20,"passing_yards":200},
                       {"player_id":"p","week":2,"attempts":30,"passing_yards":300},
                       {"player_id":"p","week":3,"attempts":25,"passing_yards":250}])
    proj, opp, eff = usage_projection(rows,"p","passing_yards")
    assert abs(eff-10)<1e-9 and opp > 0 and proj > 0


def test_prediction_identifies_no_side_as_positive_probability_edge():
    from predictions import predict_market
    games = pd.DataFrame([
        {"player_id":"p1", "week":1, "position":"WR", "targets":4, "receiving_yards":10},
        {"player_id":"p1", "week":2, "position":"WR", "targets":5, "receiving_yards":20},
        {"player_id":"p1", "week":3, "position":"WR", "targets":4, "receiving_yards":30},
        {"player_id":"p1", "week":4, "position":"WR", "targets":6, "receiving_yards":40},
    ])
    market = {"stat_key":"receiving_yards", "parse_status":"PARSED", "operator":">=", "threshold":50,
              "market_yes_probability":.60, "yes_ask":.65, "no_ask":.45}
    result = predict_market(market, {"player_id":"p1", "player_name":"Example Player", "team":"SEA", "position":"WR"},
                            games, "ACTIVE", simulations=1000)
    assert result["no_edge_pp"] > 0
    assert result["positive_edge_side"] == "NO"
