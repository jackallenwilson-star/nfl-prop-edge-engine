import pandas as pd
from features import prepare_player_games, summarize_player


def test_current_season_filter_and_zero_games_with_snap_counts():
    stats = pd.DataFrame([
        {"player_id":"p1","season":2026,"season_type":"REG","week":1,"receiving_yards":10,"targets":2,"receptions":1},
        {"player_id":"p1","season":2025,"season_type":"REG","week":1,"receiving_yards":99,"targets":5,"receptions":4},
    ])
    snaps = pd.DataFrame([
        {"player_id":"p1","season":2026,"week":1,"offense_snaps":30},
        {"player_id":"p1","season":2026,"week":2,"offense_snaps":25},
    ])
    out = prepare_player_games(stats, 2026, snaps)
    assert set(out.week) == {1,2}
    assert out.loc[out.week == 2, "receiving_yards"].iloc[0] == 0
    s = summarize_player(out, "p1", "receiving_yards", 5, ">=")
    assert s["games"] == 2
    assert s["cleared"] == 1
    assert s["sample_complete"]


def test_unavailable_stat_is_not_filled_with_zero():
    stats = pd.DataFrame([{"player_id":"p2","season":2026,"season_type":"REG","week":1,"receiving_yards":12}])
    snaps = pd.DataFrame([{"player_id":"p2","season":2026,"week":1,"offense_snaps":20}])
    out = prepare_player_games(stats, 2026, snaps)
    assert out.receiving_yards.iloc[0] == 12
    assert pd.isna(out.tackles.iloc[0])


def test_nflverse_player_stats_selects_exact_season_asset_and_schema():
    from nfl_data import NFLVerseClient

    client = NFLVerseClient()
    client.get_release = lambda tag: {
        "tag_name": "stats_player",
        "assets": [
            {"name": "stats_player_week_2025.csv", "browser_download_url": "https://example/2025"},
            {"name": "stats_player_week_2026.csv", "browser_download_url": "https://example/2026"},
        ],
    }
    client._download_frame = lambda asset, tag: pd.DataFrame([
        {"player_id": "p1", "season": int(asset["name"].split("_")[-1].split(".")[0]),
         "week": 1, "passing_yards": 200, "passing_interceptions": 1}
    ])
    live = client.load_player_stats(2026)
    assert live.season.unique().tolist() == [2026]
    assert live.attrs["seasons_loaded"] == [2026]


def test_current_feature_panel_maps_nflverse_interceptions_without_mixing_seasons():
    stats = pd.DataFrame([
        {"player_id":"p1", "season":2026, "season_type":"REG", "week":1,
         "passing_interceptions":1, "passing_yards":240},
        {"player_id":"p1", "season":2025, "season_type":"REG", "week":1,
         "passing_interceptions":4, "passing_yards":500},
    ])
    out = prepare_player_games(stats, 2026)
    assert out.interceptions.iloc[0] == 1
    assert out.passing_yards.iloc[0] == 240
