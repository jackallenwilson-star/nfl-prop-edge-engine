from kalshi_api import normalize_market_prices


def test_dollar_and_legacy_price_normalization():
    a = normalize_market_prices({"yes_bid_dollars":"0.48", "yes_ask_dollars":"0.52"})
    assert a["market_yes_probability"] == 0.5
    b = normalize_market_prices({"yes_bid":48, "yes_ask":52})
    assert b["market_yes_probability"] == 0.5


def test_asks_derive_from_opposite_bids():
    a = normalize_market_prices({"yes_bid_dollars":"0.40", "no_bid_dollars":"0.45"})
    assert abs(a["yes_ask"] - .55) < 1e-9
    assert abs(a["no_ask"] - .60) < 1e-9
    assert abs(a["market_yes_probability"] - .475) < 1e-9


def test_missing_quote_does_not_fabricate_midpoint():
    a = normalize_market_prices({"last_price_dollars":"0.50"})
    assert a["market_yes_probability"] is None
    assert a["quote_label"] == "LAST TRADE ONLY"


def test_discovery_keeps_open_events_when_unopened_query_fails():
    from kalshi_api import KalshiClient

    class StubClient(KalshiClient):
        def __init__(self):
            pass
        def list_series(self):
            return [{"ticker":"NFL-PROPS", "title":"NFL Player Props"}]
        def list_events(self, series_ticker=None, status="open"):
            if status == "unopened":
                raise RuntimeError("status unsupported by this API response")
            return [{"ticker":"NFL-EVENT", "title":"NFL player receiving yards", "markets":[
                {"ticker":"NFL-MKT", "title":"Player receiving yards 50+"}
            ]}]
        def list_markets(self, event_ticker=None, series_ticker=None, status="open"):
            return []

    markets, diagnostics = StubClient().discover_nfl_markets()
    assert any(m.get("ticker") == "NFL-MKT" for m in markets)
    assert diagnostics["markets_seen"] >= 1
