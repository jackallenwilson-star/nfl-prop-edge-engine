import numpy as np
import pandas as pd

from backtesting import walk_forward_player_stat, run_stat_backtest


def test_walk_forward_uses_only_prior_rows():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2025, "week": 1, "receiving_yards": 10},
        {"player_id": "p", "season": 2025, "week": 2, "receiving_yards": 20},
        {"player_id": "p", "season": 2025, "week": 3, "receiving_yards": 30},
        {"player_id": "p", "season": 2025, "week": 4, "receiving_yards": 40},
    ])
    out = walk_forward_player_stat(x, "receiving_yards", min_history=3)
    assert len(out) == 1
    assert out.iloc[0].actual == 40
    assert out.iloc[0].prediction_formula_a == 20
    assert out.iloc[0].prediction_formula_b == 20
    # Usage/ensemble remain unavailable when actual target opportunities are absent.
    assert pd.isna(out.iloc[0].prediction_usage)
    assert pd.isna(out.iloc[0].prediction_ensemble)


def test_walk_forward_does_not_mix_seasons():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2025, "week": 1, "receiving_yards": 100},
        {"player_id": "p", "season": 2025, "week": 2, "receiving_yards": 100},
        {"player_id": "p", "season": 2025, "week": 3, "receiving_yards": 100},
        {"player_id": "p", "season": 2025, "week": 4, "receiving_yards": 100},
        {"player_id": "p", "season": 2026, "week": 1, "receiving_yards": 10},
        {"player_id": "p", "season": 2026, "week": 2, "receiving_yards": 20},
        {"player_id": "p", "season": 2026, "week": 3, "receiving_yards": 30},
        {"player_id": "p", "season": 2026, "week": 4, "receiving_yards": 40},
    ])
    out = walk_forward_player_stat(x, "receiving_yards", min_history=3)
    row = out[out.season == 2026].iloc[0]
    assert row.week == 4
    assert row.prediction_season_average == 20


def test_future_game_cannot_change_earlier_prediction():
    base = pd.DataFrame([
        {"player_id": "p", "season": 2026, "week": 1, "receiving_yards": 10},
        {"player_id": "p", "season": 2026, "week": 2, "receiving_yards": 20},
        {"player_id": "p", "season": 2026, "week": 3, "receiving_yards": 30},
        {"player_id": "p", "season": 2026, "week": 4, "receiving_yards": 40},
    ])
    changed = pd.concat([
        base,
        pd.DataFrame([{"player_id": "p", "season": 2026, "week": 5, "receiving_yards": 999}]),
    ], ignore_index=True)
    a = walk_forward_player_stat(base, "receiving_yards").query("week == 4").iloc[0]
    b = walk_forward_player_stat(changed, "receiving_yards").query("week == 4").iloc[0]
    assert a.prediction_formula_a == b.prediction_formula_a
    assert a.prediction_formula_b == b.prediction_formula_b


def test_verified_zero_stat_game_is_retained_but_inactive_is_removed():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2026, "week": 1, "receiving_yards": 10, "participated": True},
        {"player_id": "p", "season": 2026, "week": 2, "receiving_yards": 0, "participated": True},
        {"player_id": "p", "season": 2026, "week": 3, "receiving_yards": 20, "participated": True},
        {"player_id": "p", "season": 2026, "week": 4, "receiving_yards": 999, "participated": False},
        {"player_id": "p", "season": 2026, "week": 5, "receiving_yards": 30, "participated": True},
    ])
    out = walk_forward_player_stat(x, "receiving_yards", min_history=3)
    assert len(out) == 1
    assert out.iloc[0].week == 5
    assert out.iloc[0].prior_season_average == 10
    assert out.iloc[0].actual == 30


def test_walk_forward_usage_uses_only_prior_opportunities():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2026, "week": 1, "receiving_yards": 40, "targets": 5},
        {"player_id": "p", "season": 2026, "week": 2, "receiving_yards": 50, "targets": 5},
        {"player_id": "p", "season": 2026, "week": 3, "receiving_yards": 60, "targets": 6},
        {"player_id": "p", "season": 2026, "week": 4, "receiving_yards": 70, "targets": 7},
    ])
    out = walk_forward_player_stat(x, "receiving_yards", min_history=3)
    row = out.iloc[0]
    efficiency = (40 + 50 + 60) / (5 + 5 + 6)
    expected_targets = 0.60 * 5.3333333333 + 0.40 * (16 / 3)
    assert np.isclose(row.prediction_usage, expected_targets * efficiency)


def test_prediction_bands_are_ordered_and_nonnegative():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2026, "week": i, "rushing_yards": v, "carries": c}
        for i, (v, c) in enumerate([(2, 2), (8, 3), (15, 4), (4, 2), (22, 5)], start=1)
    ])
    row = walk_forward_player_stat(x, "rushing_yards", min_history=3).iloc[0]
    assert row.prediction_season_average_p10 >= 0
    assert row.prediction_season_average_p10 <= row.prediction_season_average_p25
    assert row.prediction_season_average_p25 <= row.prediction_season_average_p75
    assert row.prediction_season_average_p75 <= row.prediction_season_average_p90


def test_run_stat_backtest_returns_projection_metrics_and_detail():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2025, "week": i, "rushing_yards": val, "carries": i}
        for i, val in enumerate([10, 15, 20, 25, 30, 35], start=1)
    ])
    summary, detail = run_stat_backtest(x, stat_columns=["rushing_yards"], min_history=3)
    assert not summary.empty
    assert not detail.empty
    assert set(["mae", "rmse", "bias", "coverage_80_band", "skill_vs_season_average"]).issubset(summary.columns)
    assert "predicted" in detail.columns
    assert "actual" in detail.columns
    assert "error" in detail.columns
    assert "market_probability" not in detail.columns
    assert "odds" not in detail.columns
    assert "ALL SEASONS" in set(summary.season)


def test_missing_stat_values_are_not_filled_with_zero():
    x = pd.DataFrame([
        {"player_id": "p", "season": 2026, "week": 1, "receiving_yards": 10},
        {"player_id": "p", "season": 2026, "week": 2, "receiving_yards": np.nan},
        {"player_id": "p", "season": 2026, "week": 3, "receiving_yards": 20},
        {"player_id": "p", "season": 2026, "week": 4, "receiving_yards": 30},
    ])
    out = walk_forward_player_stat(x, "receiving_yards", min_history=2)
    assert list(out.week) == [4]
    assert out.iloc[0].prior_games == 2
    assert out.iloc[0].prior_season_average == 15
