import numpy as np
from probability_model import edge_calculations, settlement_mask, simulate_prop
from market_parser import parse_yes_condition


def test_edge_percentage_point_examples():
    assert round(edge_calculations(.50,.55)["yes_edge_pp"],1) == 5.0
    assert round(edge_calculations(.50,.45)["yes_edge_pp"],1) == -5.0
    assert round(edge_calculations(.60,.52)["yes_edge_pp"],1) == -8.0


def test_exact_settlement_operators():
    x=np.array([49,50,51])
    assert settlement_mask(x,">=",50).tolist()==[False,True,True]
    assert settlement_mask(x,">",50).tolist()==[False,False,True]
    assert settlement_mask(x,"==",50).tolist()==[False,True,False]
    assert settlement_mask(x,"<",50).tolist()==[True,False,False]


def test_simulation_reproducible():
    a=simulate_prop([10,20,30,40],25,"receiving_yards",">=",25,simulations=1000,seed=4)
    b=simulate_prop([10,20,30,40],25,"receiving_yards",">=",25,simulations=1000,seed=4)
    assert a["model_yes_probability"]==b["model_yes_probability"]


def test_market_yes_condition_parser_is_explicit():
    assert parse_yes_condition({"title":"Will Chris Player have over 50.5 receiving yards?"})["operator"] == ">"
    assert parse_yes_condition({"title":"Will Chris Player record 50+ receiving yards?"})["operator"] == ">="
    assert parse_yes_condition({"title":"Will Chris Player record at least 50 receiving yards?"})["threshold"] == 50
    assert parse_yes_condition({"title":"Chris Player receiving yards"})["parse_status"] == "UNAVAILABLE"
