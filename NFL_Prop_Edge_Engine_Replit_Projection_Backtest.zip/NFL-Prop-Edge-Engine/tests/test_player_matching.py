import pandas as pd
from player_matching import find_player_match, game_matches_market


def test_exact_player_and_game_match():
    players = pd.DataFrame([{"player_id":"id1","player_display_name":"Example Player","recent_team":"SEA","position":"WR"}])
    game = {"home_team":"SEA","away_team":"SF"}
    market = {"title":"Will Example Player have over 50.5 receiving yards?", "event_title":"San Francisco 49ers at Seattle Seahawks"}
    assert game_matches_market(game, market)
    assert find_player_match(market, players, game)["player_id"] == "id1"


def test_ambiguous_player_is_not_matched():
    players = pd.DataFrame([{"player_id":"1","player_display_name":"Alex Smith","recent_team":"SEA"},
                            {"player_id":"2","player_display_name":"Alex Smith","recent_team":"SF"}])
    market = {"title":"Alex Smith passing yards"}
    assert find_player_match(market, players, None) is None
