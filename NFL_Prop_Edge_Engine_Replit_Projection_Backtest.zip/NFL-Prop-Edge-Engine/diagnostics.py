"""Data quality diagnostics helpers."""
from datetime import datetime, timezone
from config import STALE_QUOTE_SECONDS


def source_record(name, ok, detail="", count=None):
    return {"source": name, "status": "OK" if ok else "UNAVAILABLE", "detail": detail,
            "count": count, "checked_at": datetime.now(timezone.utc).isoformat()}


def quote_freshness(market):
    """Timestamp the live quote capture; reject explicitly old quote update timestamps."""
    import pandas as pd
    now = pd.Timestamp.now(tz="UTC")
    raw = market.get("updated_time") or market.get("last_updated_time") or market.get("updated_at")
    if raw:
        try:
            ts = pd.Timestamp(raw)
            ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
            age = (now-ts).total_seconds()
            return {"quote_timestamp": ts.isoformat(), "quote_age_seconds": age,
                    "quote_fresh": age <= STALE_QUOTE_SECONDS, "quote_freshness": "FRESH" if age <= STALE_QUOTE_SECONDS else "STALE"}
        except Exception: pass
    # Response-time snapshot is recorded because current quote fields were retrieved just now.
    return {"quote_timestamp": now.isoformat(), "quote_age_seconds": 0.0,
            "quote_fresh": True, "quote_freshness": "RETRIEVED NOW; SOURCE UPDATE TIME NOT PROVIDED"}
