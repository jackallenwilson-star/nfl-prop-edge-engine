"""Current-season-only player game panels, summaries and participation quality."""
from __future__ import annotations
import numpy as np
import pandas as pd

STAT_COLUMNS = ["passing_yards", "passing_tds", "attempts", "completions", "interceptions",
                "rushing_yards", "carries", "rushing_tds", "receiving_yards", "receptions", "targets", "receiving_tds",
                "sacks", "tackles", "def_interceptions", "passes_defended"]


def _id_col(df):
    return next((c for c in ("player_id", "gsis_id") if c in df.columns), None)


def prepare_player_games(stats: pd.DataFrame, season: int, snaps: pd.DataFrame | None = None) -> pd.DataFrame:
    if stats is None or stats.empty: return pd.DataFrame()
    x = stats.copy()
    idc = _id_col(x)
    if idc is None: return pd.DataFrame()
    x["player_id"] = x[idc].astype(str)
    x["season"] = pd.to_numeric(x["season"], errors="coerce")
    x["week"] = pd.to_numeric(x["week"], errors="coerce")
    x = x[x["season"].eq(int(season))].copy()
    if "season_type" in x:
        x = x[x["season_type"].astype(str).str.upper().isin(["REG", "REGULAR", "REGULAR SEASON"])].copy()
    if "week" in x: x["week"] = pd.to_numeric(x["week"], errors="coerce")
    # Normalize documented nflverse weekly-stat field names to internal canonical names.
    # Do not confuse offensive interceptions thrown with defensive interceptions.
    aliases = {
        "interceptions": ("passing_interceptions",),
        "attempts": ("passing_attempts",),
        "completions": ("passing_completions",),
        "sacks": ("def_sacks",),
        "passes_defended": ("def_pass_defended",),
    }
    for target, sources in aliases.items():
        if target not in x:
            source = next((col for col in sources if col in x), None)
            if source: x[target] = x[source]
    # Normalize common defensive fields only when explicitly supplied upstream.
    if "passes_defended" not in x and "def_pass_defended" in x: x["passes_defended"] = x["def_pass_defended"]
    if "tackles" not in x and {"def_tackles_solo", "def_tackles_with_assist"}.issubset(x.columns):
        solo = pd.to_numeric(x["def_tackles_solo"], errors="coerce")
        assist = pd.to_numeric(x["def_tackles_with_assist"], errors="coerce")
        x["tackles"] = solo + assist
    elif "tackles" not in x and "def_tackles_combined" in x:
        x["tackles"] = x["def_tackles_combined"]
    available_stats = set(c for c in STAT_COLUMNS if c in x.columns)
    for col in STAT_COLUMNS:
        if col not in x: x[col] = np.nan
        x[col] = pd.to_numeric(x[col], errors="coerce")
    # If snap counts exist, merge them to include verified participants who had zero box-score stats.
    participation = False
    if snaps is not None and not snaps.empty:
        s = snaps.copy()
        # Never join participation records using display names; IDs must be consistent.
        sid = _id_col(s)
        if sid and {"season", "week"}.issubset(s.columns):
            s["player_id"] = s[sid].astype(str)
            s["season"] = pd.to_numeric(s["season"], errors="coerce")
            s["week"] = pd.to_numeric(s["week"], errors="coerce")
            s = s[s["season"].eq(int(season))].copy()
            keys = ["player_id", "season", "week"]
            snap_metric = next((c for c in ("offense_snaps", "offense_pct", "off_pct", "snaps") if c in s.columns), None)
            if snap_metric:
                s["participation_metric"] = pd.to_numeric(s[snap_metric], errors="coerce")
                s = s[keys + ["participation_metric"]].drop_duplicates(keys, keep="last")
                x = x.drop_duplicates(keys, keep="last").merge(s, on=keys, how="outer", suffixes=("", "_snap"))
                participation = True
                stat_activity = x[list(available_stats)].fillna(0).sum(axis=1).gt(0) if available_stats else pd.Series(False, index=x.index)
                x["participated"] = x["participation_metric"].fillna(0).gt(0) | stat_activity
                x["participation_verified"] = x["participation_metric"].notna()
                # Zero-fill only fields actually supplied by this release, for verified participants.
                for col in available_stats: x.loc[x["participation_metric"].fillna(0).gt(0), col] = x.loc[x["participation_metric"].fillna(0).gt(0), col].fillna(0)
    if "participated" not in x:
        x["participated"] = True
        x["participation_verified"] = False
    x = x[x["participated"]].copy()
    x["week"] = pd.to_numeric(x["week"], errors="coerce")
    x = x.dropna(subset=["week", "player_id"]).sort_values(["player_id", "week"])
    x["week"] = x["week"].astype(int)
    x.attrs["participation_verified"] = participation
    return x


def summarize_player(games: pd.DataFrame, player_id: str, stat: str, threshold=None, operator=None) -> dict:
    if games is None or games.empty or stat not in games:
        return {"games": 0, "average": None, "last3": None, "last5": None, "last10": None,
                "high": None, "low": None, "hit_rate": None, "cleared": None, "sample_complete": False}
    rows = games[games.player_id.astype(str) == str(player_id)].sort_values("week")
    values = pd.to_numeric(rows[stat], errors="coerce").dropna()
    if values.empty:
        return {"games": 0, "average": None, "last3": None, "last5": None, "last10": None,
                "high": None, "low": None, "hit_rate": None, "cleared": None, "sample_complete": False}
    result = {"games": int(len(values)), "average": float(values.mean()),
              "last3": float(values.tail(3).mean()), "last5": float(values.tail(5).mean()),
              "last10": float(values.tail(10).mean()), "high": float(values.max()),
              "low": float(values.min()), "sample_complete": bool(rows.get("participation_verified", pd.Series(False, index=rows.index)).all())}
    result.update({"hit_rate": None, "cleared": None, "pushes": 0, "below": None})
    if threshold is not None and operator:
        v = values.to_numpy(dtype=float)
        if operator == ">=": hits = v >= threshold; pushes = np.zeros(len(v), dtype=bool)
        elif operator == ">": hits = v > threshold; pushes = np.zeros(len(v), dtype=bool)
        elif operator == "<=": hits = v <= threshold; pushes = np.zeros(len(v), dtype=bool)
        elif operator == "<": hits = v < threshold; pushes = np.zeros(len(v), dtype=bool)
        elif operator == "==": hits = v == threshold; pushes = np.zeros(len(v), dtype=bool)
        else: hits = np.zeros(len(v), dtype=bool); pushes = np.zeros(len(v), dtype=bool)
        result["cleared"] = int(hits.sum()); result["pushes"] = int(pushes.sum())
        result["below"] = int((~hits & ~pushes).sum())
        result["hit_rate"] = float(hits.mean()) if len(v) else None
    return result


def prepare_historical_player_games(stats: pd.DataFrame, snaps: pd.DataFrame | None = None) -> pd.DataFrame:
    """Build a separate all-seasons panel for backtesting; never use this for live averages."""
    if stats is None or stats.empty or "season" not in stats.columns:
        return pd.DataFrame()
    seasons = sorted(pd.to_numeric(stats.season, errors="coerce").dropna().astype(int).unique())
    panels = [prepare_player_games(stats, season, snaps) for season in seasons]
    panels = [p for p in panels if p is not None and not p.empty]
    if not panels: return pd.DataFrame()
    out = pd.concat(panels, ignore_index=True).sort_values(["season", "player_id", "week"]).reset_index(drop=True)
    out.attrs["historical_only"] = True
    out.attrs["seasons"] = seasons
    return out
