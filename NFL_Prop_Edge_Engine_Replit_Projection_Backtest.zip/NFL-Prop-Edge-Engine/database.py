"""SQLite persistence for snapshots and prediction history."""
from __future__ import annotations
import sqlite3, json
from datetime import datetime, timezone
from config import DB_PATH


def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(DB_PATH)


def init_db():
    with connect() as con:
        con.execute("CREATE TABLE IF NOT EXISTS runs (run_id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, season INTEGER, week INTEGER, status TEXT, diagnostics TEXT)")
        con.execute("CREATE TABLE IF NOT EXISTS market_snapshots (id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, ticker TEXT, captured_at TEXT, payload TEXT, FOREIGN KEY(run_id) REFERENCES runs(run_id))")
        con.execute("CREATE TABLE IF NOT EXISTS predictions (id INTEGER PRIMARY KEY AUTOINCREMENT, run_id INTEGER, ticker TEXT, player_id TEXT, model_version TEXT, captured_at TEXT, payload TEXT, FOREIGN KEY(run_id) REFERENCES runs(run_id))")
        con.execute("CREATE INDEX IF NOT EXISTS idx_predictions_ticker ON predictions(ticker)")


def save_run(season, week, markets, predictions, diagnostics, status="COMPLETE", model_version="0.1.0-foundation"):
    now = datetime.now(timezone.utc).isoformat()
    with connect() as con:
        cur = con.execute("INSERT INTO runs(created_at,season,week,status,diagnostics) VALUES(?,?,?,?,?)",
                          (now, season, week, status, json.dumps(diagnostics, default=str)))
        run_id = cur.lastrowid
        for m in markets:
            con.execute("INSERT INTO market_snapshots(run_id,ticker,captured_at,payload) VALUES(?,?,?,?)",
                        (run_id, str(m.get("ticker", "")), now, json.dumps(m, default=str)))
        for p in predictions:
            con.execute("INSERT INTO predictions(run_id,ticker,player_id,model_version,captured_at,payload) VALUES(?,?,?,?,?,?)",
                        (run_id, str(p.get("ticker", "")), str(p.get("player_id", "")), model_version, now, json.dumps(p, default=str)))
    return run_id


def load_latest_predictions():
    with connect() as con:
        row = con.execute("SELECT run_id FROM runs ORDER BY run_id DESC LIMIT 1").fetchone()
        if not row: return []
        items = con.execute("SELECT payload FROM predictions WHERE run_id=?", (row[0],)).fetchall()
    return [json.loads(r[0]) for r in items]


def load_run_history(limit=30):
    with connect() as con:
        rows = con.execute("SELECT run_id,created_at,season,week,status,diagnostics FROM runs ORDER BY run_id DESC LIMIT ?", (limit,)).fetchall()
    return [{"run_id":r[0],"created_at":r[1],"season":r[2],"week":r[3],"status":r[4],"diagnostics":r[5]} for r in rows]
