"""Candidate recent-performance formulas. These are not claimed to be optimized."""
import numpy as np


def weighted_recent(summary: dict, formula: str = "A") -> float | None:
    if not summary or summary.get("average") is None: return None
    if formula.upper() == "A":
        pairs = [("average", .40), ("last10", .25), ("last5", .20), ("last3", .15)]
    else:
        pairs = [("average", .40), ("last5", .35), ("last3", .25)]
    available = [(summary.get(k), w) for k, w in pairs if summary.get(k) is not None]
    if not available: return None
    return float(sum(float(v)*w for v,w in available) / sum(w for _,w in available))


def shrink_projection(raw: float | None, games: int, positional_baseline: float | None, k: float = 5.0):
    if raw is None: return None
    if positional_baseline is None: return float(raw)
    n = max(0, int(games))
    return float((n/(n+k))*raw + (k/(n+k))*positional_baseline)
